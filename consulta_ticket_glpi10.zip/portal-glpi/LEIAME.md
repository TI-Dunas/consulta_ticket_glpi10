# Portal de Consulta de Chamados (GLPI)

Página pública, sem login, onde o usuário digita o **número do chamado** e vê o status,
as datas, o técnico e o histórico. A área **/admin** guarda a conexão com a API do GLPI
e define o que o portal mostra.

## 1. Subir o portal (HTTPS na porta 8443)

Copie a pasta `portal-glpi` para o servidor (ex.: `/opt/portal-glpi`) e rode:

```bash
cd /opt/portal-glpi
nano docker-compose.yml        # troque PORTAL_SENHA e confira PORTAL_HOSTS
docker compose up -d --build
firewall-cmd --permanent --add-port=8443/tcp --add-port=8090/tcp && firewall-cmd --reload
```

* Portal público: `https://IP_DO_SERVIDOR:8443`
* Área restrita: `https://IP_DO_SERVIDOR:8443/admin`
* A porta **8090 (HTTP)** só redireciona para o HTTPS.

Sobem dois contêineres: **`portal-glpi-nginx`** (NGINX, atende os navegadores em 8443/8090 com HTTP/2 e
entrega os arquivos estáticos) e **`portal-glpi`** (a aplicação, só na rede interna do Docker, porta 8000).
O certificado continua em `data/certs` e é usado pelo NGINX; `docker compose restart` reinicia os dois.

**Atualizando de uma versão sem NGINX:** basta `docker compose up -d --build`. Se aparecer aviso de conflito
de porta ou de contêiner antigo, rode antes `docker compose down` (nada em `data/` é apagado).

### Certificado

Um certificado vale para um **nome** (ou IP), não para uma porta: o mesmo certificado serve o
GLPI (443), o portal (8443) e qualquer outro contêiner do servidor. O aviso
**"Sua conexão não é particular" (NET::ERR_CERT_AUTHORITY_INVALID)** aparece quando o
navegador não confia em **quem emitiu** o certificado. A correção é usar um certificado
emitido por uma **autoridade certificadora (CA)** e instalar essa CA nas máquinas uma vez.

* **Automático:** na primeira execução, sem certificado em `data/certs/`, o portal cria uma
  **CA interna** (`data/certs/ca.crt`) e emite com ela o certificado para `PORTAL_HOSTS`.
  Distribua o `ca.crt` por GPO (seção 8) e o aviso some. Certificados autoassinados de versões
  anteriores são trocados automaticamente por um emitido pela CA na próxima subida.
* **Um certificado para tudo (recomendado):** `sudo ./criar-certificado-interno.sh` emite um
  certificado curinga `*.grupovia.lan` para o GLPI, o portal e as outras aplicações (seção 8).
* **CA da empresa (AD CS):** emita um certificado para o nome do portal e instale com
  `usar-certificado-glpi.sh` (seção 8). As máquinas do domínio já confiam nessa CA.

O log da subida (`docker compose logs | head -20`) mostra o certificado em uso, os nomes que
ele cobre e avisa se faltar algum endereço de `PORTAL_HOSTS`, se ele for autoassinado ou se
estiver perto de vencer.

Mudou o IP ou o nome do servidor? Ajuste `PORTAL_HOSTS` e:

* se usa `criar-certificado-interno.sh`: rode-o de novo com os novos `IPS`/`NOMES`;
* se usa o certificado automático: apague **só** `data/certs/cert.pem` e `data/certs/key.pem`
  e rode `docker compose restart`.

Nos dois casos o certificado novo sai da mesma CA, então as máquinas continuam sem aviso.

O administrador do `docker-compose.yml` é criado só na primeira execução. Depois, troque a
senha pela própria área restrita. Se perder a senha, apague `data/users.json` e rode
`docker compose restart`.

## 2. Configurar a conexão (área /admin)

| Campo | Onde encontrar no GLPI |
|---|---|
| URL da API | `https://IP_DO_GLPI/apirest.php` |
| App Token | Configurar > Geral > API > (cliente da API) |
| User Token | Minhas configurações > Chaves de acesso remoto > Token da API |

Clique em **Testar conexão** e depois em **Salvar configurações**.

Use um **usuário do GLPI só para o portal**, que enxergue todas as entidades e leia
chamados e usuários. O cliente da API precisa estar ativo e liberar o IP do servidor
do portal.

## 3. O que o portal mostra

* Sempre: número, título, status (com explicação para o usuário), datas e categoria.
* Opcional: descrição, histórico, técnico, nomes das pessoas e prazo de SLA.
* **Nunca**: acompanhamentos/tarefas privados e anexos.

## 4. Segurança

Os números dos chamados são sequenciais. Com a consulta só pelo número, quem acessa o
portal pode tentar números em sequência e ler chamados de outras pessoas. Proteções:

* **Limite de consultas por minuto por IP** (padrão 10).
* **Exigir o e-mail do requerente** junto com o número (recomendado se o portal for
  acessado fora da rede interna). O e-mail é comparado com os e-mails do usuário
  requerente no GLPI e com o e-mail alternativo do chamado.
* Chamado inexistente e e-mail errado recebem a **mesma mensagem**, para não revelar
  quais números existem.
* Revise os textos dos chamados: o que estiver em acompanhamento **público** aparece no
  portal. Informações internas devem ser registradas como **privadas** no GLPI.

O NGINX repassa ao portal o IP real do visitante (o limite por IP continua valendo por pessoa) e **substitui**
o cabeçalho X-Forwarded-For que vier do navegador, para ninguém inventar outro IP. Se houver **outro** proxy
na frente do NGINX (ex.: um balanceador), troque em `nginx/nginx.conf` `$remote_addr` pelo IP vindo dele
(módulo `real_ip`), senão todos os acessos parecerão vir do mesmo IP.

### Sessão: encerrada após 5 minutos sem uso

Vale para os três logins (administrador, técnicos e "Meus chamados"):

* Sem nenhuma ação na página (clicar, digitar, rolar, mexer o mouse) por **`SESSION_IDLE_MINUTES`**
  (padrão **5**, no `docker-compose.yml`), a sessão é encerrada e a tela volta para o login com o aviso
  *"Sua sessão foi encerrada após 5 minutos sem uso"*.
* **60 segundos antes**, aparece um aviso com contagem e o botão **"Continuar conectado"**.
* Quem está só **digitando** um texto longo (sem enviar) **não** perde a sessão: a página avisa o servidor
  que o usuário está ativo.
* Várias abas do portal contam como uma só: usar uma aba mantém as outras; quando a sessão encerra, todas
  voltam para o login.
* O servidor também encerra sozinho, mesmo com o navegador fechado ou a aba esquecida: depois do prazo, o
  login deixa de valer e a sessão do usuário **no GLPI** é encerrada (`killSession`).
* O encerramento acontece entre 4min30 e 5min depois da última ação, **nunca depois de 5 minutos**: a página
  se antecipa um pouco para nunca parecer logada com a sessão já vencida no servidor.
* Mesmo em uso contínuo, ninguém fica logado mais que **`SESSION_HOURS`** (padrão 8 h).

## 5. Área de atendimento dos técnicos

Em `/admin`, os técnicos entram com o **usuário e a senha da rede (AD)**, os mesmos do GLPI.
O portal pede ao GLPI para fazer o login: o GLPI confere a senha nos diretórios LDAP dele e
o portal só libera quem tem um dos perfis configurados (padrão: `Technician`).

**Pré-requisito no GLPI:** Configurar > Geral > API > marque **"Habilitar login com
credenciais"**. O cliente da API usado pelo portal precisa liberar o IP do servidor do portal.

No atendimento, o técnico:

* filtra os chamados por técnico (padrão: os dele) e situação;
* abre o chamado e vê descrição e histórico completo (privados aparecem marcados);
* usa **"Associar a mim mesmo"** para se colocar como técnico atribuído (como no GLPI).
  Para achar chamados ainda sem técnico, filtre **Técnico: Todos** e **Situação: Novos**;
* responde com as marcações:
  * **Colocar em pendência**: envia a resposta e deixa o chamado Pendente, aguardando o cliente;
  * **Registrar como solução**: o chamado fica Solucionado e o solicitante aprova ou recusa;
  * **Privado**: nota visível só para a equipe.

Tudo é registrado no GLPI **em nome do técnico**, com as permissões do perfil dele.
O administrador local do portal continua entrando só nas configurações.

**Segurança:** com login do AD, a senha de rede dos técnicos trafega até o portal. Por isso
o portal funciona em HTTPS (porta 8443) e os cookies de sessão só trafegam criptografados.

### Alterar o técnico (transferir)

No detalhe do chamado, **↔ Alterar técnico**: escolha o técnico (e, se quiser, o motivo) e clique em
**Transferir**. O escolhido passa a ser o **único técnico atribuído** (os anteriores saem) e o portal registra
uma **nota privada** no chamado: "Chamado transferido pelo portal: Fulano → Beltrano. Motivo: …".

- É feito com o login do próprio técnico: no GLPI, o perfil dele precisa da permissão **"Atribuir"** em
  Chamados. Sem ela, o portal mostra o aviso e nada muda.
- O novo técnico é incluído **antes** de os anteriores saírem: o chamado nunca fica sem técnico.
- Não aparece em chamados solucionados ou fechados.
- Pode ser desligado em `/admin` ("Permitir que o técnico altere o técnico atribuído").

### Supervisor: trocar o técnico do chamado

Na área de atendimento, o bloco **"↔ Alterar técnico"** troca o técnico atribuído (o novo entra, os anteriores
saem e fica uma nota privada com o motivo). Tudo é feito **com o login de quem está usando**, então vale o que o
perfil dele permite no GLPI:

| Permissão do perfil no GLPI (Chamados) | O que libera no portal |
|---|---|
| **Atribuir** | "Alterar técnico" (transferir para outro técnico) |
| **Se tornando encarregado** | "Associar a mim mesmo" em chamado **sem** técnico |
| **Apropriar** | "Associar a mim mesmo" em chamado que **já tem** técnico |

O portal lê essas permissões no login e **só mostra os botões permitidos**.

Para o supervisor usar o portal:

1. em `/admin`, **Perfis do GLPI liberados**: inclua o perfil, na ordem de preferência
   (ex.: `Supervisor, Technician` — quem tiver os dois entra como Supervisor);
2. no GLPI, o perfil Supervisor precisa de **Atribuir** em Chamados;
3. o supervisor sai e entra de novo no portal (as permissões são lidas no login).

**Plugin Comportamentos ("técnico único")**: se estiver ativo no GLPI, marque a opção correspondente em
`/admin`. O portal passa a avisar que "Associar a mim mesmo" **substitui** o técnico atual; na transferência,
o próprio GLPI já retira o técnico anterior e o portal só confere e registra a nota.

## 6. Área do solicitante ("Meus chamados")

Endereço: `https://IP_DO_SERVIDOR:8443/meus-chamados` (há um link na página inicial).

* Login com o **usuário e senha da rede (AD)**: o GLPI confere a senha. Entram os perfis
  listados em "Área do solicitante" no /admin (padrão: `Self-Service`).
* Cada usuário vê **só os chamados em que é requerente**, abertos nos últimos 30 dias
  (configurável), com o técnico responsável e filtros por situação.
* **Pendentes:** o usuário responde pelo portal e o chamado volta para a equipe.
* **Solucionados:** o usuário marca **"Aprovo a solução"** (o chamado é encerrado) ou
  **"Não aprovo"** (precisa dizer o motivo; o chamado é reaberto).
* Respostas e avaliações ficam registradas no GLPI **em nome do usuário**.
* Itens privados nunca aparecem. A lista mostra até os 200 chamados mais recentes.

Pré-requisitos no GLPI: "Habilitar login com credenciais" na API (o mesmo do atendimento)
e o perfil Self-Service com permissão de acompanhar e aprovar os próprios chamados.


### Abrir chamado pelo portal

Com **"Permitir abrir chamados em /meus-chamados"** marcado em `/admin` (seção *Abertura de chamados pelo
solicitante*), aparece o botão **+ Abrir chamado**. O chamado é criado **com o login do próprio usuário**, como
na interface simplificada do GLPI: valem as permissões do perfil, o **modelo de chamado** (campos obrigatórios)
e as **regras de negócio** (atribuição de grupo, SLA etc.). O requerente é o próprio usuário e a entidade é a
entidade padrão dele.

| Opção em /admin | O que faz |
|---|---|
| Tipo do chamado | O usuário escolhe (requisição ou incidente), ou sempre um dos dois |
| Categoria | Opcional, obrigatória ou não pedir. Aparecem só as categorias marcadas como **"Visível na interface simplificada"**, filtradas pelo tipo |
| Localização | Opcional, obrigatória ou não pedir. Campo com busca por texto |
| Campos adicionais | Um por linha: `Rótulo|campo_no_GLPI|sim`. Sem o campo do GLPI (`Ramal||não`), o valor vai para o fim da descrição |
| Plugin Campos: ID do bloco | Para gravar os campos adicionais num bloco do plugin **Campos (Fields)**, como Patrimônio e Setor |

**No GLPI:** o perfil **Self-Service** precisa da permissão **Chamados > Criar** (padrão). Se o modelo de chamado
tiver campos obrigatórios (ex.: Localização), deixe-os como **Obrigatória** no portal também; caso falte algo,
o portal mostra a mensagem do GLPI ("Campos obrigatórios não foram preenchidos: …").

**Limite:** 5 chamados por minuto por usuário (erros de preenchimento não contam).

### Formulários por categoria (Compras, Novo usuário…)

Em `/admin` > **Formulários por categoria**, cada formulário fica ligado a uma ou mais categorias. Quando o
solicitante escolhe essa categoria, os campos do formulário aparecem no portal, o título é sugerido e a descrição
livre vira **"Observações"** (opcional). As respostas vão para a descrição do chamado, em uma tabela, então o
técnico vê tudo no GLPI sem plugin nenhum. O botão **"Inserir exemplo"** traz Compras e Novo usuário prontos.

```
[Compras]
categoria: Compras
titulo: Pedido de compra
ajuda: Informe o item e a justificativa. Orçamentos podem ser enviados depois, respondendo o chamado.
Item ou serviço | texto | sim
Quantidade | número | sim
Centro de custo | lista: Administrativo; Comercial; Financeiro; TI | sim
Justificativa | texto longo | sim
Precisa até | data
```

| Linha | Significado |
|---|---|
| `[Nome]` | Começa um formulário |
| `categoria:` | Nome completo da categoria (ex.: `Acessos > Novo usuário`) ou o ID. Várias separadas por `;` |
| `titulo:` / `ajuda:` | Título sugerido e texto de orientação no topo (opcionais) |
| `Rótulo \| tipo \| sim` | Um campo. Tipos: `texto`, `texto longo`, `número`, `data`, `e-mail`, `lista: A; B` (uma opção), `marcar: A; B` (várias). `sim` = obrigatório |

* Ao salvar, o portal confere a escrita (com o número da linha do erro) e avisa se alguma categoria não foi
  encontrada no GLPI. Formulário com erro não é gravado.
* A categoria precisa estar **"Visível na interface simplificada"** e a opção Categoria não pode estar como
  "Não pedir". Se a mesma categoria estiver em dois formulários, vale o primeiro.
* Tudo é conferido de novo no servidor (obrigatórios, números, datas, e-mails, opções das listas).
* Os campos adicionais gerais (seção anterior) continuam valendo e entram na mesma tabela.

## 7. Desempenho e robustez

* O **NGINX** recebe as conexões dos navegadores (milhares ao mesmo tempo, com HTTP/2 e cache de sessão TLS),
  entrega CSS/JS/ícones direto do disco e só repassa ao portal o que é dinâmico, reaproveitando conexões.
* O portal roda com **vários processos** (`PORTAL_WORKERS=4`; use até o número de núcleos) e cada um faz até
  **`PORTAL_THREADS=64`** consultas ao GLPI em paralelo. O que passar disso espera na fila em vez de dar erro.
  As conexões com o GLPI são reaproveitadas (keep-alive), sem refazer o handshake TLS a cada consulta.
* Sessões, limite de tentativas de login e cache ficam em `data/compartilhado.sqlite`,
  compartilhados entre os processos. Reiniciar o portal **não** derruba os logins.
* A lista "Meus chamados" fica em cache por 30 segundos (vem sempre atualizada ao entrar,
  ao clicar em "Atualizar" e depois de cada resposta ou avaliação).
* **Teste de carga com NGINX** (máquina de teste com **1 núcleo**, que também gerava a carga):
  * **2.500 conexões simultâneas** com login, cada uma consultando a própria sessão sem parar por 40 s:
    17 mil respostas (~425/s), **nenhum erro** e nenhuma conexão recusada. Tempo médio de 5 s só porque o
    único núcleo fazia TLS, Python e o gerador de carga ao mesmo tempo; num servidor com 4 núcleos ou mais
    fica bem menor.
  * Arquivos estáticos com 2.500 conexões: ~19 mil respostas por segundo, só o NGINX.
* **O limite real é o GLPI.** 2.500 usuários conectados não geram 2.500 consultas ao mesmo tempo (cada pessoa
  lê a tela entre um clique e outro), mas cada clique em "Meus chamados" ou no atendimento vira consultas ao
  GLPI. Com 4 × 64 = 256 em paralelo, o Apache/PHP do GLPI precisa aguentar isso (ex.: `MaxRequestWorkers` do
  Apache e `pm.max_children` do PHP-FPM). Se o GLPI ficar lento, **diminua** `PORTAL_THREADS`: o portal
  segura a fila, e o NGINX responde *"O portal está muito ocupado"* só se alguém esperar mais de 90 s.
* `docker ps` mostra `healthy`/`unhealthy` nos dois contêineres; os logs ficam limitados a 3 arquivos de 10 MB.

## 8. Um certificado para o GLPI, o portal e as outras aplicações

### 8.1 Emitir o certificado curinga (CA interna)

```bash
cd /opt/portal-glpi
sudo ./criar-certificado-interno.sh
# outros IPs/nomes:  sudo IPS="10.1.100.128 10.1.100.129" NOMES="srv-glpi" ./criar-certificado-interno.sh
```

O script:

1. usa a CA de `/etc/pki/grupovia-ca/` (cria na primeira vez; se o portal já tinha criado uma
   CA em `data/certs`, adota essa e tira a chave da CA de dentro do contêiner);
2. emite `*.grupovia.lan` + `grupovia.lan` + o IP do servidor, válido por 825 dias, em
   `/etc/pki/tls/certs/grupovia-curinga.crt` e `/etc/pki/tls/private/grupovia-curinga.key`
   (e `grupovia-curinga-cadeia.crt`, certificado + CA, para aplicações que pedem a cadeia);
3. faz o próprio servidor confiar na CA (`update-ca-trust`);
4. instala no portal (via `usar-certificado-glpi.sh`) e o reinicia.

Para **renovar**, rode de novo: o certificado sai da mesma CA e nada precisa ser redistribuído.
Guarde uma cópia de `/etc/pki/grupovia-ca/ca.key` em local seguro: quem tem essa chave
consegue emitir certificados aceitos pelas máquinas da empresa.

### 8.2 Fazer as máquinas confiarem na CA (uma vez)

GPO: Configuração do Computador > Políticas > Configurações do Windows > Configurações de
Segurança > Políticas de Chave Pública > **Autoridades de Certificação Raiz Confiáveis** >
Importar `/etc/pki/grupovia-ca/ca.crt` (ou `data/certs/ca.crt`). Chrome e Edge usam esse
repositório; no Firefox, ative `security.enterprise_roots.enabled`.

### 8.3 Usar no GLPI (Apache)

No `glpi.conf` (ou `ssl.conf`):

```apache
SSLCertificateFile    /etc/pki/tls/certs/grupovia-curinga.crt
SSLCertificateKeyFile /etc/pki/tls/private/grupovia-curinga.key
```

`systemctl reload httpd`. Com isso o portal também pode deixar **"Verificar certificado SSL"**
marcado no /admin: ele confia na CA de `data/certs/ca.crt` (e em `data/certs/ca-glpi.crt`, se o
GLPI usar outra CA) além das autoridades públicas.

### 8.4 Outras aplicações Docker no mesmo servidor (portas diferentes)

Use o mesmo par `grupovia-curinga.crt` / `.key` em cada contêiner e crie no DNS interno um nome
por aplicação apontando para o mesmo IP (`helpdesk`, `zabbix`, `wiki`... `.grupovia.lan`). O
curinga cobre um nível (`zabbix.grupovia.lan` sim, `a.zabbix.grupovia.lan` não). Copie os
arquivos para a pasta de dados de cada contêiner (como o portal faz) em vez de montar
`/etc/pki`, para não alterar o rótulo SELinux usado pelo Apache.

### 8.5 Usar um certificado existente (GLPI atual ou AD CS)

```bash
./usar-certificado-glpi.sh      # padrão: /etc/pki/tls/certs/helpdesk.crt e private/helpdesk.key
CERT=/caminho/cert.crt CHAVE=/caminho/chave.key CADEIA=/caminho/cadeia.crt ./usar-certificado-glpi.sh
```

Ele confere se a chave combina, se o nome `helpdesk.grupovia.lan` está no certificado (curinga
aceito), se não está vencido, **avisa se for autoassinado** (a causa do ERR_CERT_AUTHORITY_INVALID)
e reinicia o portal. Se algo estiver errado, nada é alterado.

## 9. Comandos úteis

```bash
docker compose logs -f          # acompanhar o funcionamento (NGINX e portal)
docker compose logs -f nginx    # só os acessos (IP, rota, status, tempo de resposta)
docker compose restart          # reiniciar
docker compose up -d --build    # aplicar atualizações
```

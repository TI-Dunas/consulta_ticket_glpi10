"""Formularios por categoria na abertura de chamados (ex.: Compras, Novo usuario).

O administrador escreve os formularios em texto, em /admin:

    [Compras]
    categoria: Compras
    titulo: Pedido de compra
    ajuda: Informe o item e a justificativa. Orcamentos podem ser enviados depois, respondendo o chamado.
    Item ou servico | texto | sim
    Quantidade | numero | sim
    Centro de custo | lista: Administrativo; TI; Comercial | sim
    Justificativa | texto longo | sim
    Precisa ate | data

Quando o solicitante escolhe uma categoria ligada a um formulario, os campos aparecem no portal
e as respostas vao para a descricao do chamado, em uma tabela.
"""
import html
import re
import unicodedata
from datetime import date

MAX_FORMULARIOS = 30
MAX_CAMPOS = 40
MAX_OPCOES = 60

# tipo -> limite de caracteres da resposta
TIPOS = {"texto": 500, "textolongo": 5000, "numero": 30, "data": 10, "email": 254, "lista": 200, "marcar": 2000}
SINONIMOS = {"texto": "texto", "textocurto": "texto", "textolongo": "textolongo", "paragrafo": "textolongo",
             "numero": "numero", "data": "data", "email": "email", "lista": "lista", "escolha": "lista",
             "marcar": "marcar", "multipla": "marcar", "caixas": "marcar"}
PROPRIEDADES = ("categoria", "titulo", "ajuda")
RE_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
RE_NUMERO = re.compile(r"^-?\d{1,15}([.,]\d{1,6})?$")


def _simples(texto):
    """Minusculas, sem acentos e sem espacos: "Texto Longo" -> "textolongo"."""
    t = unicodedata.normalize("NFKD", str(texto or "")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[\s_-]+", "", t)


def _nome_categoria(texto):
    """Compara nomes de categoria sem diferenciar maiusculas, acentos e espacos em volta do ">"."""
    t = unicodedata.normalize("NFKD", str(texto or "")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"\s*>\s*", ">", re.sub(r"\s+", " ", t)).strip()


def _sim(texto):
    return _simples(texto) in ("sim", "s", "1", "true", "obrigatorio", "obrigatoria")


def interpretar(texto):
    """Texto da configuracao -> (formularios, erros). Os erros citam a linha, para o administrador corrigir."""
    formularios, erros, atual = [], [], None
    for n, bruta in enumerate(str(texto or "").splitlines(), start=1):
        linha = bruta.strip()
        if not linha or linha.startswith("#"):
            continue
        m = re.fullmatch(r"\[(.+)\]", linha)
        if m:
            if len(formularios) >= MAX_FORMULARIOS:
                erros.append(f"Linha {n}: no máximo {MAX_FORMULARIOS} formulários.")
                atual = None
                continue
            atual = {"id": f"f{len(formularios)}", "nome": m.group(1).strip()[:80], "categorias_txt": [],
                     "titulo": "", "ajuda": "", "campos": [], "linha": n}
            formularios.append(atual)
            continue
        if atual is None:
            erros.append(f"Linha {n}: comece cada formulário com o nome entre colchetes, ex.: [Compras].")
            continue
        if "|" not in linha:
            chave, _, valor = linha.partition(":")
            prop = _simples(chave)
            if not _ or prop not in PROPRIEDADES:
                erros.append(f"Linha {n}: use \"categoria:\", \"titulo:\", \"ajuda:\" ou um campo no formato Rótulo | tipo | sim.")
                continue
            valor = valor.strip()
            if prop == "categoria":
                atual["categorias_txt"] += [c.strip() for c in valor.split(";") if c.strip()]
            else:
                atual[prop] = valor[:250 if prop == "titulo" else 1000]
            continue
        partes = [p.strip() for p in linha.split("|")]
        rotulo = partes[0][:80]
        tipo_txt, _, opcoes_txt = (partes[1] if len(partes) > 1 else "texto").partition(":")
        tipo = SINONIMOS.get(_simples(tipo_txt) or "texto")
        if not rotulo:
            erros.append(f"Linha {n}: falta o rótulo do campo.")
            continue
        if not tipo:
            erros.append(f"Linha {n}: tipo \"{tipo_txt.strip()}\" desconhecido. Use texto, texto longo, número, data, e-mail, lista ou marcar.")
            continue
        opcoes = []
        if tipo in ("lista", "marcar"):
            opcoes = list(dict.fromkeys(o.strip()[:120] for o in opcoes_txt.split(";") if o.strip()))[:MAX_OPCOES]
            if not opcoes:
                erros.append(f"Linha {n}: informe as opções separadas por ponto e vírgula, ex.: {tipo}: Opção A; Opção B")
                continue
        if len(atual["campos"]) >= MAX_CAMPOS:
            erros.append(f"Linha {n}: no máximo {MAX_CAMPOS} campos por formulário.")
            continue
        atual["campos"].append({"id": f"c{len(atual['campos'])}", "rotulo": rotulo, "tipo": tipo, "opcoes": opcoes,
                                "obrigatorio": len(partes) > 2 and _sim(partes[2])})
    for f in formularios:
        if not f["categorias_txt"]:
            erros.append(f"Formulário [{f['nome']}] (linha {f['linha']}): falta a linha \"categoria:\".")
        if not f["campos"]:
            erros.append(f"Formulário [{f['nome']}] (linha {f['linha']}): não tem nenhum campo.")
    return formularios, erros


def ligar_categorias(formularios, categorias):
    """Troca os nomes/IDs escritos em "categoria:" pelos IDs das categorias do GLPI.
    Retorna (formularios com "categorias": [ids], avisos sobre categorias nao encontradas ou repetidas)."""
    por_id = {c["id"]: c for c in categorias}
    por_nome, por_folha = {}, {}
    for c in categorias:
        nome = _nome_categoria(c["nome"])
        por_nome[nome] = c["id"]
        por_folha.setdefault(nome.split(">")[-1], []).append(c["id"])
    avisos, usadas = [], {}
    for f in formularios:
        ids = []
        for txt in f["categorias_txt"]:
            alvo = None
            if txt.isdigit() and int(txt) in por_id:
                alvo = int(txt)
            else:
                nome = _nome_categoria(txt)
                alvo = por_nome.get(nome)
                if alvo is None and len(por_folha.get(nome, [])) == 1:
                    alvo = por_folha[nome][0]
            if alvo is None:
                avisos.append(f"[{f['nome']}]: categoria \"{txt}\" não encontrada entre as categorias visíveis na interface "
                              "simplificada (use o nome completo, ex.: Compras > Equipamentos, ou o ID).")
                continue
            if alvo in usadas and usadas[alvo] != f["id"]:
                avisos.append(f"[{f['nome']}]: a categoria \"{por_id[alvo]['nome']}\" já está no formulário anterior; vale o primeiro.")
                continue
            usadas[alvo] = f["id"]
            ids.append(alvo)
        f["categorias"] = ids
    return formularios, avisos


def para_o_navegador(formularios):
    """So o necessario para desenhar o formulario (sem numeros de linha nem textos de configuracao)."""
    return [{"id": f["id"], "nome": f["nome"], "titulo": f["titulo"], "ajuda": f["ajuda"], "categorias": f["categorias"],
             "campos": [{k: c[k] for k in ("id", "rotulo", "tipo", "opcoes", "obrigatorio")} for c in f["campos"]]}
            for f in formularios if f.get("categorias")]


def da_categoria(formularios, categoria):
    for f in formularios:
        if categoria and categoria in f.get("categorias", []):
            return f
    return None


def validar(formulario, respostas):
    """Confere as respostas do solicitante. Retorna [(rotulo, valor em texto)] ou levanta ValueError com a mensagem."""
    respostas = respostas if isinstance(respostas, dict) else {}
    saida = []
    for c in formulario["campos"]:
        bruto = respostas.get(c["id"])
        rot = c["rotulo"]
        if c["tipo"] == "marcar":
            itens = [str(x).strip() for x in bruto] if isinstance(bruto, list) else []
            itens = [x for x in c["opcoes"] if x in itens]  # so opcoes validas, na ordem configurada
            valor = ", ".join(itens)
        else:
            valor = str(bruto or "").strip()
            if c["tipo"] != "textolongo":
                valor = re.sub(r"\s+", " ", valor)
            valor = valor[:TIPOS[c["tipo"]]]
        if not valor:
            if c["obrigatorio"]:
                raise ValueError(f"Preencha o campo {rot}." if c["tipo"] != "marcar" else f"Marque pelo menos uma opção em {rot}.")
            continue
        if c["tipo"] == "numero" and not RE_NUMERO.fullmatch(valor.replace(" ", "")):
            raise ValueError(f"O campo {rot} aceita só números.")
        if c["tipo"] == "email" and not RE_EMAIL.fullmatch(valor):
            raise ValueError(f"O campo {rot} precisa de um e-mail válido.")
        if c["tipo"] == "lista" and valor not in c["opcoes"]:
            raise ValueError(f"Escolha uma das opções em {rot}.")
        if c["tipo"] == "data":
            try:
                valor = date.fromisoformat(valor).strftime("%d/%m/%Y")
            except ValueError:
                raise ValueError(f"Data inválida em {rot}.")
        saida.append((rot, valor))
    return saida


def montar_html(formulario, respostas, extras_texto, observacoes):
    """Descricao do chamado: tabela com as respostas, campos adicionais e as observacoes do solicitante.
    Todo texto digitado e escapado; so a estrutura (tabela, negrito, quebras) e HTML."""
    esc = lambda t: html.escape(t).replace("\n", "<br>")
    linhas = "".join(f"<tr><td><strong>{esc(r)}</strong></td><td>{esc(v)}</td></tr>"
                     for r, v in list(respostas) + list(extras_texto))
    partes = [f"<p><strong>Formulário: {esc(formulario['nome'])}</strong></p>"]
    if linhas:
        partes.append(f'<table border="1" cellpadding="4" cellspacing="0">{linhas}</table>')
    if observacoes.strip():
        partes.append(f"<p><strong>Observações</strong><br>{esc(observacoes.strip())}</p>")
    return "".join(partes)

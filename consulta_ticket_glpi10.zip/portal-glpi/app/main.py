"""Portal publico de consulta de chamados do GLPI."""
import json
import os
import re
import secrets
import threading
import time

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

import formularios
import glpi
from compartilhado import Compartilhado
from usuarios import ErroUsuario, Usuarios

DATA_DIR = os.environ.get("DATA_DIR", "/data")
ARQ_CONFIG = os.path.join(DATA_DIR, "config.json")
STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
COOKIE = "portal_admin"
COOKIE_TEC = "portal_tecnico"
COOKIE_CLI = "portal_solicitante"
SEGUNDOS_CACHE_LISTA = 30  # lista "Meus chamados": evita repetir dezenas de consultas ao GLPI a cada clique
HORAS_SESSAO = int(os.environ.get("SESSION_HOURS", "8"))  # limite total desde o login
# sem nenhuma acao do usuario por este tempo, a sessao e encerrada (admin, tecnico e solicitante)
OCIOSO = max(60, int(float(os.environ.get("SESSION_IDLE_MINUTES", "5")) * 60))

CONFIG_PADRAO = {
    # conexao com o GLPI
    "glpi_url": "", "app_token": "", "user_token": "", "verify_ssl": False, "timeout": 30, "retries": 2,
    # aparencia
    "titulo": "Consulta de chamados",
    "mensagem": "Digite o número do chamado para acompanhar o andamento do seu atendimento.",
    # o que o portal mostra
    "exigir_email": False,
    "mostrar_descricao": True,
    "mostrar_historico": True,
    "mostrar_tecnico": True,
    "mostrar_nomes": False,
    "mostrar_sla": False,
    # protecao contra varredura de numeros
    "limite_por_minuto": 10,
    # area de atendimento: perfis do GLPI que podem entrar com usuario e senha do AD
    "atendimento_ativo": True,
    "transferir_ativo": True,     # tecnico pode trocar o tecnico atribuido (o GLPI exige a permissao "Atribuir")
    "tecnico_unico": False,       # plugin Comportamentos com "tecnico unico": incluir um tecnico substitui o atual
    "perfis_atendimento": "Technician",
    # area do solicitante ("Meus chamados"): usuarios do GLPI entram com usuario e senha do AD
    "cliente_ativo": True,
    "perfis_cliente": "Self-Service",
    "cliente_dias": 30,
    # abertura de chamados pelo solicitante
    "abertura_ativa": True,
    "abertura_tipo": "escolher",          # escolher | 1 (incidente) | 2 (requisicao)
    "abertura_categoria": "opcional",     # obrigatoria | opcional | oculta
    "abertura_local": "opcional",         # obrigatoria | opcional | oculta
    "abertura_extras": "",                # uma linha por campo: Rotulo|chave_no_glpi|sim
    "abertura_container": 0,              # plugin Campos (Fields): id do bloco, se os extras forem dele
    "abertura_formularios": "",           # formularios por categoria (Compras, Novo usuario...): ver formularios.py
}
ESCOLHAS = {"abertura_tipo": ("escolher", "1", "2"), "abertura_categoria": ("obrigatoria", "opcional", "oculta"),
            "abertura_local": ("obrigatoria", "opcional", "oculta")}
CAMPOS_BOOL = ("verify_ssl", "exigir_email", "mostrar_descricao", "mostrar_historico",
               "mostrar_tecnico", "mostrar_nomes", "mostrar_sla", "atendimento_ativo", "cliente_ativo", "transferir_ativo", "tecnico_unico",
               "abertura_ativa")

app = FastAPI(title="Portal de consulta GLPI", docs_url=None, redoc_url=None, openapi_url=None)


@app.on_event("startup")
async def ajustar_threads():
    """As rotas que consultam o GLPI rodam em threads. O padrao do FastAPI (40 por processo) vira fila
    com muitos acessos simultaneos; PORTAL_THREADS ajusta (o GLPI precisa aguentar processos x threads)."""
    import anyio.to_thread
    anyio.to_thread.current_default_thread_limiter().total_tokens = max(10, int(os.environ.get("PORTAL_THREADS", "64")))
app.mount("/static", StaticFiles(directory=STATIC), name="static")


@app.middleware("http")
async def sem_cache_de_paginas(request: Request, call_next):
    """Paginas e arquivos do portal sempre conferidos com o servidor: depois de uma atualizacao,
    o navegador nao continua usando o JavaScript antigo guardado em cache."""
    resposta = await call_next(request)
    caminho = request.url.path
    if caminho.startswith("/static/") or not caminho.startswith("/api/"):
        resposta.headers["Cache-Control"] = "no-cache"
    return resposta
conexao = glpi.Conexao()
usuarios = Usuarios(DATA_DIR)
usuarios.garantir_admin_inicial(os.environ.get("PORTAL_ADMIN", "admin"), os.environ.get("PORTAL_SENHA", ""))


# ------------------------------------------------------------------ configuracao
def ler_config():
    cfg = dict(CONFIG_PADRAO)
    try:
        with open(ARQ_CONFIG, encoding="utf-8") as f:
            cfg.update(json.load(f))
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    return cfg


def gravar_config(cfg):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = ARQ_CONFIG + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.chmod(tmp, 0o600)
    os.replace(tmp, ARQ_CONFIG)


def mesclar(novo):
    cfg = ler_config()
    for campo in ("glpi_url", "titulo", "mensagem", "perfis_atendimento", "perfis_cliente"):
        if campo in novo:
            cfg[campo] = str(novo[campo] or "").strip()[:500]
    cfg["glpi_url"] = glpi.normalizar_url(cfg["glpi_url"])
    for campo in ("app_token", "user_token"):  # em branco = manter o atual
        valor = str(novo.get(campo) or "").strip()
        if valor:
            cfg[campo] = valor
    if novo.get("limpar_app_token"):
        cfg["app_token"] = ""
    for campo in CAMPOS_BOOL:
        if campo in novo:
            cfg[campo] = bool(novo[campo])
    for campo, opcoes in ESCOLHAS.items():
        if campo in novo and str(novo[campo]) in opcoes:
            cfg[campo] = str(novo[campo])
    if "abertura_extras" in novo:
        cfg["abertura_extras"] = str(novo["abertura_extras"] or "").strip()[:3000]
    if "abertura_formularios" in novo:
        cfg["abertura_formularios"] = str(novo["abertura_formularios"] or "").strip()[:30000]
    for campo, minimo, maximo in (("timeout", 5, 300), ("retries", 1, 5), ("limite_por_minuto", 1, 120),
                                  ("cliente_dias", 1, 365), ("abertura_container", 0, 100000)):
        if campo in novo:
            try:
                cfg[campo] = min(maximo, max(minimo, int(novo[campo])))
            except (TypeError, ValueError):
                pass
    return cfg


# ------------------------------------------------------------------ estado compartilhado entre processos
compart = Compartilhado(DATA_DIR)


def faxina_de_sessoes():
    """A cada 30 s: apaga as sessoes vencidas (inatividade ou limite total) e encerra a sessao delas no GLPI,
    para o token do usuario nao continuar valido la. Roda em cada processo; cada sessao e tratada uma vez so."""
    while True:
        time.sleep(30)
        try:
            vencidas = compart.remover_expiradas()
            if vencidas:
                cfg = ler_config()
                for _, dados in vencidas:
                    if dados.get("token"):
                        glpi.logout_tecnico(cfg, dados["token"])
        except Exception as e:  # noqa: BLE001  (a faxina nunca pode derrubar o portal)
            print("Faxina de sessões:", e, flush=True)


@app.on_event("startup")
async def iniciar_faxina():
    threading.Thread(target=faxina_de_sessoes, daemon=True, name="faxina-sessoes").start()


def ip_cliente(request: Request):
    return request.client.host if request.client else "?"


def verificar_limite(ip, limite, tipo="consulta"):
    """Limite por minuto e por IP, valido para todos os processos do portal."""
    return compart.permitir(f"{tipo}|{ip}", limite)


# ------------------------------------------------------------------ paginas
@app.get("/saude")
def saude():
    """Usado pela checagem de saude do Docker (nao consulta o GLPI)."""
    return {"ok": True}


@app.get("/")
def pagina_publica():
    return FileResponse(os.path.join(STATIC, "index.html"))


@app.get("/admin")
def pagina_admin():
    return FileResponse(os.path.join(STATIC, "admin.html"))


@app.get("/meus-chamados")
def pagina_meus_chamados():
    return FileResponse(os.path.join(STATIC, "meus-chamados.html"))


# ------------------------------------------------------------------ API publica
@app.get("/api/portal")
def api_portal():
    cfg = ler_config()
    return {"titulo": cfg["titulo"], "mensagem": cfg["mensagem"], "exigir_email": cfg["exigir_email"],
            "configurado": bool(cfg["glpi_url"] and cfg["user_token"]),
            "cliente_ativo": bool(cfg["cliente_ativo"]), "cliente_dias": cfg["cliente_dias"]}


@app.post("/api/consulta")
def api_consulta(dados: dict, request: Request):
    cfg = ler_config()
    numero = re.sub(r"\D", "", str(dados.get("numero", "")))
    if not numero or len(numero) > 15:
        raise HTTPException(400, "Informe o número do chamado (somente números).")
    if not verificar_limite(ip_cliente(request), cfg["limite_por_minuto"]):
        raise HTTPException(429, "Muitas consultas em pouco tempo. Aguarde um minuto e tente novamente.")
    if cfg["exigir_email"] and not str(dados.get("email", "")).strip():
        raise HTTPException(400, "Informe o e-mail usado na abertura do chamado.")
    try:
        resultado = conexao.consultar(cfg, int(numero), dados.get("email"))
    except glpi.GlpiError:
        raise HTTPException(503, "A consulta está indisponível no momento. Tente novamente em alguns minutos.")
    if not resultado:
        # mesma resposta para "nao existe" e "e-mail nao confere": nao revela quais numeros existem
        msg = "Chamado não encontrado. Confira o número"
        msg += " e o e-mail informados." if cfg["exigir_email"] else " informado."
        raise HTTPException(404, msg)
    return resultado


# ------------------------------------------------------------------ area administrativa
def cookie(response, request, nome, valor):
    response.set_cookie(nome, valor, httponly=True, samesite="strict", secure=request.url.scheme == "https",
                        max_age=HORAS_SESSAO * 3600)


def admin_da_requisicao(request: Request, response: Response):
    """Administrador logado (renovando o prazo de inatividade do cookie) ou None."""
    token = request.cookies.get(COOKIE, "")
    u = usuarios.ler_sessao(token)
    if not u or u["role"] != "admin":
        return None
    novo = usuarios.renovar_sessao(token, OCIOSO)
    if novo:
        cookie(response, request, COOKIE, novo)
    return u


def admin_atual(request: Request, response: Response):
    u = admin_da_requisicao(request, response)
    if not u:
        raise HTTPException(401, "Sessão encerrada. Entre novamente.")
    return u


# ---- sessoes dos tecnicos (compartilhadas entre os processos, em data/compartilhado.sqlite)


def perfis_atendimento(cfg):
    return [p.strip() for p in str(cfg.get("perfis_atendimento") or "").split(",") if p.strip()]


def tecnico_atual(request: Request):
    sid = request.cookies.get(COOKIE_TEC, "")
    s = compart.obter_sessao("tecnico", sid, OCIOSO)
    if not s:
        raise HTTPException(401, "Sessão encerrada. Entre novamente.")
    return {**s, "sid": sid}


def encerrar_sessao(sid):
    s = compart.remover_sessao(sid)
    if s:
        glpi.logout_tecnico(ler_config(), s["token"])


@app.post("/api/admin/login")
def api_login(dados: dict, request: Request, response: Response):
    login = str(dados.get("username", "")).strip()
    senha = str(dados.get("password", ""))
    if not verificar_limite(ip_cliente(request), 10, "login"):
        raise HTTPException(429, "Muitas tentativas de login. Aguarde um minuto.")
    # 1) administrador local do portal (configuracoes)
    u = usuarios.autenticar(login, senha)
    if u and u["role"] == "admin":
        cookie(response, request, COOKIE, usuarios.criar_sessao(u["username"], OCIOSO))
        return {"tipo": "admin", "nome": u["name"], "ocioso": OCIOSO}
    # 2) tecnico: o GLPI confere usuario e senha no AD/LDAP configurado nele
    cfg = ler_config()
    if not cfg["atendimento_ativo"] or not login or not senha:
        time.sleep(1)
        raise HTTPException(401, "Usuário ou senha incorretos.")
    try:
        t = glpi.login_tecnico(cfg, login, senha, perfis_atendimento(cfg))
    except glpi.AcessoNegado:
        raise HTTPException(403, "Seu usuário não tem um perfil liberado para o atendimento neste portal.")
    except glpi.GlpiError as e:
        raise HTTPException(503, str(e))
    if not t:
        time.sleep(1)
        raise HTTPException(401, "Usuário ou senha incorretos.")
    cookie(response, request, COOKIE_TEC, compart.criar_sessao("tecnico", t, HORAS_SESSAO, OCIOSO))
    return {"tipo": "tecnico", "nome": t["nome"], "ocioso": OCIOSO}


@app.post("/api/admin/logout")
def api_logout(request: Request, response: Response):
    encerrar_sessao(request.cookies.get(COOKIE_TEC, ""))
    response.delete_cookie(COOKIE)
    response.delete_cookie(COOKIE_TEC)
    return {"ok": True}


@app.get("/api/admin/me")
def api_me(request: Request, response: Response):
    """Tambem e o "estou aqui" das telas: chamado quando o usuario mexe na pagina, renova a sessao."""
    u = admin_da_requisicao(request, response)
    if u:
        return {"tipo": "admin", "nome": u["name"], "ocioso": OCIOSO}
    t = tecnico_atual(request)
    return {"tipo": "tecnico", "nome": t["nome"], "uid": t["uid"], "perfil": t["perfil"], "ocioso": OCIOSO}


@app.post("/api/admin/senha")
def api_senha(dados: dict, u: dict = Depends(admin_atual)):
    if not usuarios.autenticar(u["username"], str(dados.get("atual", ""))):
        raise HTTPException(400, "A senha atual está incorreta.")
    try:
        usuarios.alterar(u["username"], senha=str(dados.get("nova", "")))
    except ErroUsuario as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


@app.get("/api/admin/config")
def api_config(_: dict = Depends(admin_atual)):
    cfg = ler_config()
    publico = {k: v for k, v in cfg.items() if k not in ("app_token", "user_token")}
    publico["app_token_set"] = bool(cfg["app_token"])
    publico["user_token_set"] = bool(cfg["user_token"])
    return publico


@app.post("/api/admin/config")
def api_config_salvar(novo: dict, u: dict = Depends(admin_atual)):
    cfg = mesclar(novo)
    forms, erros = formularios.interpretar(cfg["abertura_formularios"])
    if erros:  # nao grava formulario com erro: o solicitante veria um formulario quebrado
        raise HTTPException(400, "Formulários por categoria: " + " ".join(erros[:5]))
    gravar_config(cfg)
    resposta = api_config(u)
    resposta["avisos_formularios"] = []
    if forms:
        try:
            compart.cache_apagar("abertura|opcoes")  # categorias novas no GLPI aparecem na hora
            _, resposta["avisos_formularios"] = formularios.ligar_categorias(forms, opcoes_abertura(cfg)["categorias"])
        except glpi.GlpiError as e:
            resposta["avisos_formularios"] = [f"Salvo, mas não deu para conferir as categorias no GLPI: {e}"]
    return resposta


@app.post("/api/admin/teste")
def api_teste(novo: dict, _: dict = Depends(admin_atual)):
    teste = glpi.Conexao()  # conexao separada: nao derruba a sessao usada pelo portal
    try:
        return {"ok": True, "message": teste.testar(mesclar(novo))}
    except glpi.GlpiError as e:
        return {"ok": False, "message": str(e)}


# ------------------------------------------------------------------ area de atendimento (tecnicos)
def glpi_do_tecnico(funcao, t, *args):
    """Executa uma chamada com a sessao do tecnico; se ela expirou no GLPI, pede novo login."""
    try:
        return funcao(ler_config(), t["token"], *args)
    except glpi.SessaoExpirada:
        encerrar_sessao(t["sid"])
        raise HTTPException(401, "Sua sessão no GLPI expirou. Entre novamente.")
    except glpi.GlpiError as e:
        raise HTTPException(503, str(e))


def detalhe_tecnico(t, tid):
    """Detalhe do chamado com a sessao do tecnico; o historico usa a conta de servico se a sessao nao conseguir le-lo."""
    cfg = ler_config()
    return glpi_do_tecnico(glpi.detalhar_chamado, t, tid, lambda caminho: conexao.lista(cfg, caminho))


@app.get("/api/atendimento/opcoes")
def api_opcoes(t: dict = Depends(tecnico_atual)):
    cfg = ler_config()
    try:
        tecnicos = conexao.tecnicos(cfg, perfis_atendimento(cfg))
    except glpi.GlpiError:
        tecnicos = []
    if not any(x["id"] == t["uid"] for x in tecnicos):
        tecnicos = [{"id": t["uid"], "nome": t["nome"]}] + tecnicos
    d = t.get("direitos_chamado")

    def tem(bit):
        return d is None or bool(d & bit)   # sessao antiga sem a informacao: deixa o GLPI decidir

    return {"eu": t["uid"], "tecnicos": tecnicos, "perfil": t.get("perfil"),
            "pode_transferir": bool(cfg.get("transferir_ativo", True)) and tem(glpi.DIREITO_ATRIBUIR),
            "pode_assumir_livre": tem(glpi.DIREITO_ENCARREGADO), "pode_apropriar": tem(glpi.DIREITO_APROPRIAR),
            "tecnico_unico": bool(cfg.get("tecnico_unico")),
            "situacoes": [{"id": k, "nome": v[1]} for k, v in glpi.SITUACOES.items()]}


@app.get("/api/atendimento/chamados")
def api_chamados(tecnico: int = 0, situacao: str = "abertos", pagina: int = 1, t: dict = Depends(tecnico_atual)):
    return glpi_do_tecnico(glpi.listar_chamados, t, tecnico, situacao, max(1, pagina))


@app.get("/api/atendimento/chamado/{tid}")
def api_chamado(tid: int, t: dict = Depends(tecnico_atual)):
    d = detalhe_tecnico(t, tid)
    if not d:
        raise HTTPException(404, "Chamado não encontrado ou sem permissão para você.")
    return d


@app.post("/api/atendimento/chamado/{tid}/responder")
def api_responder(tid: int, dados: dict, t: dict = Depends(tecnico_atual)):
    texto = str(dados.get("texto") or "").strip()
    acao = dados.get("acao") if dados.get("acao") in ("resposta", "pendente", "solucao") else "resposta"
    if len(texto) < 3:
        raise HTTPException(400, "Escreva a resposta antes de enviar.")
    msg = glpi_do_tecnico(glpi.responder_chamado, t, tid, texto, acao, bool(dados.get("privado")))
    return {"message": msg, "chamado": detalhe_tecnico(t, tid)}


@app.post("/api/atendimento/chamado/{tid}/assumir")
def api_assumir(tid: int, t: dict = Depends(tecnico_atual)):
    msg = glpi_do_tecnico(glpi.atribuir_a_mim, t, tid, t["uid"])
    return {"message": msg, "chamado": detalhe_tecnico(t, tid)}


@app.post("/api/atendimento/chamado/{tid}/transferir")
def api_transferir(tid: int, dados: dict, t: dict = Depends(tecnico_atual)):
    cfg = ler_config()
    if not cfg.get("transferir_ativo", True):
        raise HTTPException(403, "A troca de técnico pelo portal está desativada.")
    d = t.get("direitos_chamado")
    if d is not None and not d & glpi.DIREITO_ATRIBUIR:
        raise HTTPException(403, f"O seu perfil no GLPI ({t.get('perfil')}) não tem a permissão \"Atribuir\" em Chamados.")
    try:
        novo = int(dados.get("para") or 0)
    except (TypeError, ValueError):
        novo = 0
    try:
        tecnicos = conexao.tecnicos(cfg, perfis_atendimento(cfg))
    except glpi.GlpiError:
        tecnicos = []
    nomes = {x["id"]: x["nome"] for x in tecnicos}
    nomes.setdefault(t["uid"], t["nome"])
    if novo not in nomes:
        raise HTTPException(400, "Escolha um técnico da lista.")
    motivo = re.sub(r"\s+", " ", str(dados.get("motivo") or "")).strip()[:500]
    msg = glpi_do_tecnico(glpi.transferir_chamado, t, tid, novo, motivo, nomes)
    return {"message": msg, "chamado": detalhe_tecnico(t, tid)}


# ------------------------------------------------------------------ area do solicitante ("Meus chamados")


def perfis_cliente(cfg):
    return [p.strip() for p in str(cfg.get("perfis_cliente") or "").split(",") if p.strip()]


def cliente_atual(request: Request):
    sid = request.cookies.get(COOKIE_CLI, "")
    s = compart.obter_sessao("cliente", sid, OCIOSO)
    if not s:
        raise HTTPException(401, "Sessão encerrada. Entre novamente.")
    return {**s, "sid": sid}


def encerrar_cliente(sid):
    s = compart.remover_sessao(sid)
    if s:
        glpi.logout_tecnico(ler_config(), s["token"])


def chamado_do_cliente(cfg, tid, uid):
    """Garante que o chamado existe e que o usuario logado e requerente dele."""
    try:
        if uid not in conexao.requerentes(cfg, tid):
            raise HTTPException(404, "Chamado não encontrado entre os seus.")
    except glpi.GlpiError as e:
        raise HTTPException(503, str(e))


@app.post("/api/cliente/login")
def api_cliente_login(dados: dict, request: Request, response: Response):
    cfg = ler_config()
    if not cfg["cliente_ativo"]:
        raise HTTPException(403, "O acesso aos seus chamados está desativado neste portal.")
    login = str(dados.get("username", "")).strip()
    senha = str(dados.get("password", ""))
    if not verificar_limite(ip_cliente(request), 10, "login-cliente"):
        raise HTTPException(429, "Muitas tentativas de login. Aguarde um minuto.")
    if not login or not senha:
        raise HTTPException(400, "Informe usuário e senha.")
    try:
        u = glpi.login_tecnico(cfg, login, senha, perfis_cliente(cfg))
    except glpi.AcessoNegado:
        raise HTTPException(403, "Seu usuário não tem acesso à área de chamados deste portal.")
    except glpi.GlpiError as e:
        raise HTTPException(503, str(e))
    if not u:
        time.sleep(1)
        raise HTTPException(401, "Usuário ou senha incorretos.")
    sid = compart.criar_sessao("cliente", u, HORAS_SESSAO, OCIOSO)
    compart.cache_apagar(f"meus|{u['uid']}|{cfg['cliente_dias']}")  # ao entrar, a lista vem sempre atualizada
    cookie(response, request, COOKIE_CLI, sid)
    return {"nome": u["nome"], "ocioso": OCIOSO}


@app.post("/api/cliente/logout")
def api_cliente_logout(request: Request, response: Response):
    encerrar_cliente(request.cookies.get(COOKIE_CLI, ""))
    response.delete_cookie(COOKIE_CLI)
    return {"ok": True}


@app.get("/api/cliente/me")
def api_cliente_me(c: dict = Depends(cliente_atual)):
    cfg = ler_config()
    return {"nome": c["nome"], "login": c["login"], "dias": cfg["cliente_dias"], "pode_abrir": bool(cfg["abertura_ativa"]),
            "ocioso": OCIOSO}


@app.get("/api/cliente/chamados")
def api_cliente_chamados(atualizar: bool = False, c: dict = Depends(cliente_atual)):
    cfg = ler_config()
    try:
        chave = f"meus|{c['uid']}|{cfg['cliente_dias']}"
        guardado = None if atualizar else compart.cache_ler(chave)
        if guardado is None:
            itens, total = conexao.meus_chamados(cfg, c["uid"], int(cfg["cliente_dias"]))
            guardado = {"itens": itens, "total": total}
            compart.cache_gravar(chave, guardado, SEGUNDOS_CACHE_LISTA)
        return {"dias": cfg["cliente_dias"], **guardado}
    except glpi.GlpiError as e:
        raise HTTPException(503, str(e))


@app.get("/api/cliente/chamado/{tid}")
def api_cliente_chamado(tid: int, c: dict = Depends(cliente_atual)):
    cfg = ler_config()
    chamado_do_cliente(cfg, tid, c["uid"])
    # o proprio solicitante ve descricao, historico publico e tecnico (nunca itens privados)
    visao = {**cfg, "exigir_email": False, "mostrar_descricao": True, "mostrar_historico": True, "mostrar_tecnico": True}
    try:
        d = conexao.consultar(visao, tid)
    except glpi.GlpiError as e:
        raise HTTPException(503, str(e))
    if not d:
        raise HTTPException(404, "Chamado não encontrado entre os seus.")
    d["pode_responder"] = d["status"]["codigo"] == 4
    d["pode_avaliar"] = d["status"]["codigo"] == 5
    return d


def acao_cliente(c, funcao, *args):
    cfg = ler_config()
    compart.cache_apagar(f"meus|{c['uid']}|{cfg['cliente_dias']}")  # a lista mostra o efeito na hora
    try:
        return funcao(cfg, c["token"], *args)
    except glpi.SessaoExpirada:
        encerrar_cliente(c["sid"])
        raise HTTPException(401, "Sua sessão expirou. Entre novamente.")
    except glpi.GlpiError as e:
        raise HTTPException(400, str(e))


# ------------------------------------------------------------------ abertura de chamados pelo solicitante
TIPOS = {1: "Incidente", 2: "Requisição"}


def campos_extras(cfg):
    """Linhas "Rotulo|chave|sim" da configuracao -> [{rotulo, chave, obrigatorio, id}]."""
    extras = []
    for n, linha in enumerate(str(cfg.get("abertura_extras") or "").splitlines()):
        partes = [p.strip() for p in linha.split("|")]
        if not partes or not partes[0] or partes[0].startswith("#"):
            continue
        chave = partes[1] if len(partes) > 1 else ""
        obrig = len(partes) > 2 and partes[2].lower() in ("sim", "s", "1", "true", "obrigatorio", "obrigatório")
        extras.append({"id": f"x{n}", "rotulo": partes[0][:80], "chave": re.sub(r"[^A-Za-z0-9_]", "", chave)[:80],
                       "obrigatorio": obrig})
    return extras


def opcoes_abertura(cfg):
    """Categorias e localizacoes do GLPI, com cache de 10 minutos compartilhado entre os processos."""
    opcoes = compart.cache_ler("abertura|opcoes")
    if opcoes is None:
        opcoes = conexao.opcoes_abertura(cfg)
        compart.cache_gravar("abertura|opcoes", opcoes, 600)
    return opcoes


def formularios_ativos(cfg, opcoes):
    """Formularios da configuracao ligados as categorias do GLPI (vazio se a categoria nao e pedida)."""
    if cfg["abertura_categoria"] == "oculta":
        return []
    forms, erros = formularios.interpretar(cfg["abertura_formularios"])
    if erros:
        return []
    return formularios.ligar_categorias(forms, opcoes["categorias"])[0]


@app.get("/api/cliente/abertura")
def api_cliente_abertura(c: dict = Depends(cliente_atual)):
    cfg = ler_config()
    if not cfg["abertura_ativa"]:
        raise HTTPException(403, "A abertura de chamados pelo portal está desativada.")
    try:
        opcoes = opcoes_abertura(cfg)
    except glpi.GlpiError as e:
        raise HTTPException(503, str(e))
    return {"formularios": formularios.para_o_navegador(formularios_ativos(cfg, opcoes)),
            "tipo": cfg["abertura_tipo"], "tipos": [{"id": k, "nome": v} for k, v in TIPOS.items()],
            "categoria": cfg["abertura_categoria"], "local": cfg["abertura_local"],
            "categorias": opcoes["categorias"] if cfg["abertura_categoria"] != "oculta" else [],
            "locais": opcoes["locais"] if cfg["abertura_local"] != "oculta" else [],
            "extras": [{k: e[k] for k in ("id", "rotulo", "obrigatorio")} for e in campos_extras(cfg)]}


@app.post("/api/cliente/abrir")
def api_cliente_abrir(dados: dict, request: Request, c: dict = Depends(cliente_atual)):
    cfg = ler_config()
    if not cfg["abertura_ativa"]:
        raise HTTPException(403, "A abertura de chamados pelo portal está desativada.")
    titulo = re.sub(r"\s+", " ", str(dados.get("titulo") or "")).strip()
    descricao = str(dados.get("descricao") or "").strip()
    if len(titulo) < 3:
        raise HTTPException(400, "Escreva um título para o chamado.")
    if cfg["abertura_tipo"] in ("1", "2"):
        tipo = int(cfg["abertura_tipo"])
    else:
        try:
            tipo = int(dados.get("tipo"))
        except (TypeError, ValueError):
            tipo = 0
        if tipo not in TIPOS:
            raise HTTPException(400, "Escolha se é uma requisição ou um incidente.")

    def numero(campo):
        try:
            return int(dados.get(campo) or 0)
        except (TypeError, ValueError):
            return 0

    campos = {"titulo": titulo[:250], "descricao": descricao[:20000], "tipo": tipo, "extras_glpi": {}}
    try:
        opcoes = opcoes_abertura(cfg)
    except glpi.GlpiError as e:
        raise HTTPException(503, str(e))
    if cfg["abertura_categoria"] != "oculta":
        cat = numero("categoria")
        validas = {x["id"]: x for x in opcoes["categorias"]}
        if cat and (cat not in validas or not validas[cat]["requisicao" if tipo == 2 else "incidente"]):
            raise HTTPException(400, "Categoria inválida para este tipo de chamado.")
        if not cat and cfg["abertura_categoria"] == "obrigatoria":
            raise HTTPException(400, "Escolha a categoria.")
        campos["categoria"] = cat or None
    if cfg["abertura_local"] != "oculta":
        loc = numero("local")
        if loc and loc not in {x["id"] for x in opcoes["locais"]}:
            raise HTTPException(400, "Localização inválida.")
        if not loc and cfg["abertura_local"] == "obrigatoria":
            raise HTTPException(400, "Escolha a localização.")
        campos["local"] = loc or None

    # formulario da categoria (Compras, Novo usuario...): as respostas substituem a descricao livre
    form = formularios.da_categoria(formularios_ativos(cfg, opcoes), campos.get("categoria"))
    respostas = []
    if form:
        enviado = dados.get("formulario") if isinstance(dados.get("formulario"), dict) else {}
        if enviado.get("id") != form["id"]:
            raise HTTPException(400, "O formulário desta categoria foi atualizado. Clique em Cancelar e abra o chamado de novo.")
        try:
            respostas = formularios.validar(form, enviado.get("respostas"))
        except ValueError as e:
            raise HTTPException(400, str(e))
    elif len(descricao) < 5:
        raise HTTPException(400, "Descreva o que você precisa.")

    valores = dados.get("extras") if isinstance(dados.get("extras"), dict) else {}
    linhas_texto = []
    for e in campos_extras(cfg):
        valor = re.sub(r"\s+", " ", str(valores.get(e["id"]) or "")).strip()[:500]
        if not valor:
            if e["obrigatorio"]:
                raise HTTPException(400, f"Preencha o campo {e['rotulo']}.")
            continue
        if e["chave"]:
            campos["extras_glpi"][e["chave"]] = valor
        else:
            linhas_texto.append(f"{e['rotulo']}: {valor}")
    if campos["extras_glpi"] and int(cfg["abertura_container"] or 0):
        campos["extras_glpi"]["c_id"] = int(cfg["abertura_container"])
    if form:
        extras_texto = [tuple(x.split(": ", 1)) for x in linhas_texto]
        campos["descricao_html"] = formularios.montar_html(form, respostas, extras_texto, descricao[:20000])
    elif linhas_texto:
        campos["descricao"] = campos["descricao"] + "\n\n" + "\n".join(linhas_texto)

    # limite contado so para envios validos (erros de preenchimento nao gastam tentativas)
    if not verificar_limite(f"{c['uid']}", 5, "abrir"):
        raise HTTPException(429, "Muitos chamados em seguida. Aguarde um minuto e tente de novo.")
    tid = acao_cliente(c, glpi.cliente_abrir_chamado, c["uid"], c.get("entidade"), campos)
    return {"id": tid, "message": f"Chamado nº {tid} aberto. A equipe de suporte já recebeu o seu pedido."}


@app.post("/api/cliente/chamado/{tid}/responder")
def api_cliente_responder(tid: int, dados: dict, c: dict = Depends(cliente_atual)):
    cfg = ler_config()
    chamado_do_cliente(cfg, tid, c["uid"])
    if conexao.status_do_chamado(cfg, tid) != 4:
        raise HTTPException(400, "Este chamado não está aguardando a sua resposta.")
    texto = str(dados.get("texto") or "").strip()
    if len(texto) < 2:
        raise HTTPException(400, "Escreva a sua resposta antes de enviar.")
    return {"message": acao_cliente(c, glpi.cliente_responder, tid, texto[:5000])}


@app.post("/api/cliente/chamado/{tid}/avaliar")
def api_cliente_avaliar(tid: int, dados: dict, c: dict = Depends(cliente_atual)):
    cfg = ler_config()
    chamado_do_cliente(cfg, tid, c["uid"])
    if conexao.status_do_chamado(cfg, tid) != 5:
        raise HTTPException(400, "Este chamado não está aguardando a sua avaliação.")
    if dados.get("aprovado") not in (True, False):
        raise HTTPException(400, "Marque se aprova ou não aprova a solução.")
    comentario = str(dados.get("comentario") or "")[:5000]
    return {"message": acao_cliente(c, glpi.cliente_avaliar, tid, bool(dados["aprovado"]), comentario)}

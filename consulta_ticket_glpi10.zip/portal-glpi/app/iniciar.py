"""Inicia o portal em HTTPS.

Certificado (em /data/certs):
  * cert.pem + key.pem existentes: sao usados como estao (ex.: o certificado do GLPI, copiado
    pelo script usar-certificado-glpi.sh, ou um emitido pela CA da empresa).
  * Se nao existirem: o portal cria uma AUTORIDADE CERTIFICADORA interna (data/certs/ca.crt,
    gerada uma unica vez e reaproveitada) e emite com ela um certificado para PORTAL_HOSTS.
    Basta distribuir o ca.crt UMA vez (GPO) para as maquinas confiarem no portal, inclusive
    depois de renovacoes ou mudanca de nome/IP.

Tambem sobe um redirecionador HTTP (PORTA_HTTP) para https://...:PORTA_HTTPS_PUBLICA.

Com ATRAS_DO_NGINX=1 (docker-compose.yml padrao), o NGINX fica na frente: ele atende o HTTPS (8443) e o
redirecionamento (8090) usando o mesmo certificado de data/certs, e o portal responde so em HTTP na rede
interna do Docker (PORTA_INTERNA, padrao 8000). O certificado continua sendo criado e conferido aqui.
"""
import datetime
import fnmatch
import ipaddress
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import uvicorn

DATA_DIR = os.environ.get("DATA_DIR", "/data")
PASTA_CERT = os.path.join(DATA_DIR, "certs")
CERT = os.path.join(PASTA_CERT, "cert.pem")
CHAVE = os.path.join(PASTA_CERT, "key.pem")
CA_CERT = os.path.join(PASTA_CERT, "ca.crt")
CA_CHAVE = os.path.join(PASTA_CERT, "ca.key")
PORTA_HTTPS = int(os.environ.get("PORTA_HTTPS", "8443"))
PORTA_HTTP = int(os.environ.get("PORTA_HTTP", "8090"))
PORTA_PUBLICA = os.environ.get("PORTA_HTTPS_PUBLICA", str(PORTA_HTTPS))
ATRAS_DO_NGINX = os.environ.get("ATRAS_DO_NGINX", "0").strip().lower() in ("1", "sim", "true", "yes")
PORTA_INTERNA = int(os.environ.get("PORTA_INTERNA", "8000"))
HOSTS = [h.strip() for h in os.environ.get("PORTAL_HOSTS", "localhost").split(",") if h.strip()]
ORG = "Portal de Consulta GLPI"
DIAS_AVISO = 30


def _gravar(caminho, dados, privado=False):
    os.makedirs(PASTA_CERT, exist_ok=True)
    novo = caminho + ".novo"
    with open(novo, "wb") as f:
        f.write(dados)
    if privado:
        os.chmod(novo, 0o600)
    os.replace(novo, caminho)


def _carregar_ou_criar_ca():
    """Reaproveita a CA interna (para nao ter de redistribuir) ou cria uma nova."""
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID

    if os.path.exists(CA_CERT) and os.path.exists(CA_CHAVE):
        ca = x509.load_pem_x509_certificate(open(CA_CERT, "rb").read())
        chave = serialization.load_pem_private_key(open(CA_CHAVE, "rb").read(), password=None)
        pub = serialization.PublicFormat.SubjectPublicKeyInfo
        if (ca.public_key().public_bytes(serialization.Encoding.PEM, pub)
                == chave.public_key().public_bytes(serialization.Encoding.PEM, pub)):
            return ca, chave
        print("ATENCAO: data/certs/ca.key nao corresponde a data/certs/ca.crt.", flush=True)
    elif os.path.exists(CA_CERT):
        print("ATENCAO: data/certs/ca.crt existe, mas a chave da CA nao esta aqui (ela fica em "
              "/etc/pki/grupovia-ca quando se usa criar-certificado-interno.sh). Criando uma CA NOVA: "
              "ela tera de ser distribuida de novo. Para evitar, rode ./criar-certificado-interno.sh.", flush=True)

    chave = rsa.generate_private_key(public_exponent=65537, key_size=4096)
    nome = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, f"{ORG} - CA interna"),
                      x509.NameAttribute(NameOID.ORGANIZATION_NAME, ORG)])
    agora = datetime.datetime.now(datetime.timezone.utc)
    ski = x509.SubjectKeyIdentifier.from_public_key(chave.public_key())
    ca = (x509.CertificateBuilder()
          .subject_name(nome).issuer_name(nome).public_key(chave.public_key())
          .serial_number(x509.random_serial_number())
          .not_valid_before(agora - datetime.timedelta(minutes=5))
          .not_valid_after(agora + datetime.timedelta(days=3650))
          .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
          .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=True, crl_sign=True,
                                       content_commitment=False, key_encipherment=False,
                                       data_encipherment=False, key_agreement=False,
                                       encipher_only=False, decipher_only=False), critical=True)
          .add_extension(ski, critical=False)
          .sign(chave, hashes.SHA256()))
    _gravar(CA_CHAVE, chave.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                          serialization.NoEncryption()), privado=True)
    _gravar(CA_CERT, ca.public_bytes(serialization.Encoding.PEM))
    print(f"CA interna criada: {CA_CERT} (distribua este arquivo por GPO)", flush=True)
    return ca, chave


def gerar_certificado():
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

    ca, ca_chave = _carregar_ou_criar_ca()
    chave = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    nomes = []
    for h in HOSTS + ["localhost"]:
        try:
            nomes.append(x509.IPAddress(ipaddress.ip_address(h)))
        except ValueError:
            nomes.append(x509.DNSName(h))
    agora = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder()
            .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, HOSTS[0]),
                                     x509.NameAttribute(NameOID.ORGANIZATION_NAME, ORG)]))
            .issuer_name(ca.subject).public_key(chave.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(agora - datetime.timedelta(minutes=5))
            .not_valid_after(agora + datetime.timedelta(days=825))
            .add_extension(x509.SubjectAlternativeName(list(dict.fromkeys(nomes))), critical=False)
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(x509.KeyUsage(digital_signature=True, key_encipherment=True,
                                         content_commitment=False, data_encipherment=False,
                                         key_agreement=False, key_cert_sign=False, crl_sign=False,
                                         encipher_only=False, decipher_only=False), critical=True)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
            .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_chave.public_key()),
                           critical=False)
            .sign(ca_chave, hashes.SHA256()))
    _gravar(CHAVE, chave.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL,
                                       serialization.NoEncryption()), privado=True)
    _gravar(CERT, cert.public_bytes(serialization.Encoding.PEM))
    print(f"Certificado gerado pela CA interna para: {', '.join(HOSTS)} (valido por 825 dias)", flush=True)


def _nomes_do_cert(c):
    from cryptography import x509
    try:
        san = c.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    except x509.ExtensionNotFound:
        return [], []
    return san.get_values_for_type(x509.DNSName), [str(i) for i in san.get_values_for_type(x509.IPAddress)]


def _cobre(host, dns, ips):
    try:
        return str(ipaddress.ip_address(host)) in ips
    except ValueError:
        pass
    host = host.lower()
    for n in dns:
        n = n.lower()
        if n == host:
            return True
        # curinga vale para UM nivel: *.grupovia.lan cobre helpdesk.grupovia.lan
        if n.startswith("*.") and host.count(".") == n.count(".") and fnmatch.fnmatchcase(host, n):
            return True
    return False


def _autogerado_antigo(c):
    """Certificado autoassinado das versoes anteriores (sem CA): o navegador nunca confia nele."""
    from cryptography.x509.oid import NameOID
    org = c.subject.get_attributes_for_oid(NameOID.ORGANIZATION_NAME)
    return c.issuer == c.subject and bool(org) and org[0].value == ORG


def conferir_certificado():
    """Mostra no log qual certificado esta em uso e avisa sobre problemas comuns."""
    from cryptography import x509
    c = x509.load_pem_x509_certificate(open(CERT, "rb").read())
    if _autogerado_antigo(c):
        print("Certificado autoassinado antigo encontrado: trocando por um emitido pela CA interna.", flush=True)
        gerar_certificado()
        c = x509.load_pem_x509_certificate(open(CERT, "rb").read())
    dns, ips = _nomes_do_cert(c)
    fim = c.not_valid_after_utc
    print(f"  emitido para: {c.subject.rfc4514_string()}", flush=True)
    print(f"  nomes (SAN):  {', '.join(dns + ips) or '(nenhum)'}", flush=True)
    print(f"  emissor:      {c.issuer.rfc4514_string()}", flush=True)
    print(f"  valido ate:   {fim:%d/%m/%Y}", flush=True)
    faltando = [h for h in HOSTS if not _cobre(h, dns, ips)]
    if faltando:
        print(f"  ATENCAO: o certificado nao cobre {', '.join(faltando)}. Acessar por esse(s) "
              "endereco(s) dara aviso no navegador.", flush=True)
    restam = (fim - datetime.datetime.now(datetime.timezone.utc)).days
    if restam < 0:
        print("  ATENCAO: o certificado esta VENCIDO.", flush=True)
    elif restam <= DIAS_AVISO:
        print(f"  ATENCAO: o certificado vence em {restam} dia(s).", flush=True)
    if c.issuer == c.subject:
        print("  ATENCAO: certificado autoassinado. Os navegadores so confiam nele se ele mesmo for "
              "instalado como raiz confiavel. Prefira um emitido por CA (veja o LEIAME).", flush=True)
    if os.path.exists(CA_CERT):
        print("  CA interna para distribuir (GPO): data/certs/ca.crt", flush=True)


class Redirecionar(BaseHTTPRequestHandler):
    def _ir(self):
        host = (self.headers.get("Host") or HOSTS[0]).split(":")[0]
        self.send_response(301)
        self.send_header("Location", f"https://{host}:{PORTA_PUBLICA}{self.path}")
        self.send_header("Content-Length", "0")
        self.end_headers()

    do_GET = do_HEAD = do_POST = _ir

    def log_message(self, *args):
        pass


if __name__ == "__main__":
    if not (os.path.exists(CERT) and os.path.exists(CHAVE)):
        gerar_certificado()
    else:
        print("Usando o certificado existente em", PASTA_CERT, flush=True)
    try:
        conferir_certificado()
    except Exception as e:  # noqa: BLE001
        print("  (não foi possível ler os dados do certificado:", e, ")", flush=True)
    processos = max(1, int(os.environ.get("PORTAL_WORKERS", "4")))
    if ATRAS_DO_NGINX:
        # sem TLS e sem redirecionador: o NGINX cuida das conexoes dos navegadores. O IP real do visitante
        # chega no X-Forwarded-For (FORWARDED_ALLOW_IPS no docker-compose.yml).
        print(f"Portal atras do NGINX: HTTP interno na porta {PORTA_INTERNA}, com {processos} processo(s) e "
              f"{os.environ.get('PORTAL_THREADS', '64')} threads cada", flush=True)
        uvicorn.run("main:app", host="0.0.0.0", port=PORTA_INTERNA, proxy_headers=True, log_level="warning",
                    workers=processos, timeout_keep_alive=75, backlog=4096)
        raise SystemExit(0)
    if PORTA_HTTP:
        servidor = ThreadingHTTPServer(("0.0.0.0", PORTA_HTTP), Redirecionar)
        threading.Thread(target=servidor.serve_forever, daemon=True).start()
        print(f"HTTP na porta {PORTA_HTTP}: redirecionando para HTTPS na porta {PORTA_PUBLICA}", flush=True)
    print(f"Portal em HTTPS na porta {PORTA_HTTPS}, com {processos} processo(s)", flush=True)
    uvicorn.run("main:app", host="0.0.0.0", port=PORTA_HTTPS, ssl_certfile=CERT, ssl_keyfile=CHAVE,
                proxy_headers=True, log_level="warning", workers=processos,
                timeout_keep_alive=15, limit_concurrency=1000)

/* Encerramento da sessao por inatividade (area restrita e "Meus chamados").
 *
 * - Conta como uso: clicar, digitar, tocar, rolar e mexer o mouse na pagina, em QUALQUER aba do portal
 *   (as abas combinam entre si pelo localStorage; se uma encerra, todas encerram).
 * - Enquanto o usuario usa a pagina, avisa o servidor no maximo a cada 30 s (mesmo so digitando um texto
 *   longo, sem enviar nada), para a sessao nao vencer no meio do preenchimento.
 * - 60 s antes do fim mostra um aviso com contagem e o botao "Continuar conectado".
 * - No fim, faz o logout (o servidor tambem encerra sozinho, mesmo com o navegador fechado).
 */
window.SessaoOciosa = (function () {
  "use strict";
  const K_ACAO = "portal:ultima-acao", K_SERV = "portal:ultimo-servidor", K_FIM = "portal:sessao-encerrada";
  const PING_A_CADA = 30000, MARGEM_SERVIDOR = 15000, AVISO_ANTES = 60000;
  let cfg = null, relogio = null, aviso = null, pingando = false, ultimoEvento = 0;
  let ultimaAcao = 0, ultimoServidor = 0;

  const agora = () => Date.now();
  function ler(k) { try { return parseInt(localStorage.getItem(k) || "0", 10) || 0; } catch (e) { return 0; } }
  function gravar(k, v) { try { localStorage.setItem(k, String(v)); } catch (e) { /* modo privado: vale so esta aba */ } }

  function sincronizar() {  // a aba usa o mais recente entre ela e as outras abas
    ultimaAcao = Math.max(ultimaAcao, ler(K_ACAO));
    ultimoServidor = Math.max(ultimoServidor, ler(K_SERV));
  }
  // o servidor renova o prazo a cada acao, mas so grava a cada 15 s: o fim aqui nunca passa do fim no servidor
  const prazo = () => Math.min(ultimaAcao + cfg.ms, ultimoServidor + cfg.ms - MARGEM_SERVIDOR);

  function servidor() {
    if (!cfg) return;
    ultimoServidor = agora();
    gravar(K_SERV, ultimoServidor);
  }

  async function ping() {
    if (pingando || !cfg) return;
    pingando = true;
    try {
      const r = await fetch(cfg.ping, { cache: "no-store" });
      if (r.ok) servidor();
      else if (r.status === 401) encerrar(false);
    } catch (e) { /* sem rede: tenta de novo na proxima acao */ }
    pingando = false;
  }

  function acao() {
    if (!cfg) return;
    const t = agora();
    if (t - ultimoEvento < 1000) return;  // mousemove dispara dezenas de vezes por segundo
    ultimoEvento = t;
    sincronizar();
    if (t >= prazo()) return;  // ja venceu: o relogio encerra; mexer agora nao ressuscita a sessao
    ultimaAcao = t;
    gravar(K_ACAO, t);
    if (t - ultimoServidor > PING_A_CADA) ping();
  }

  function mostrarAviso(restante) {
    if (!aviso) {
      aviso = document.createElement("div");
      aviso.className = "aviso-ocioso";
      aviso.setAttribute("role", "alertdialog");
      aviso.setAttribute("aria-live", "assertive");
      const texto = document.createElement("span");
      const bt = document.createElement("button");
      bt.type = "button"; bt.className = "btn primario"; bt.textContent = "Continuar conectado";
      bt.addEventListener("click", () => { ultimoEvento = 0; acao(); ping(); esconderAviso(); });
      aviso.append(texto, bt);
      document.body.appendChild(aviso);
    }
    const s = Math.max(0, Math.ceil(restante / 1000));
    aviso.firstChild.textContent = `Por falta de uso, sua sessão será encerrada em ${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}.`;
  }
  function esconderAviso() { if (aviso) { aviso.remove(); aviso = null; } }

  function conferir() {
    if (!cfg) return;
    sincronizar();
    const restante = prazo() - agora();
    if (restante <= 0) encerrar(true);
    else if (restante <= AVISO_ANTES) mostrarAviso(restante);
    else esconderAviso();
  }

  async function encerrar(avisarOutrasAbas) {
    if (!cfg) return;
    const c = cfg;
    parar();
    if (avisarOutrasAbas) gravar(K_FIM, agora());
    try { await c.sair(); } catch (e) { /* o servidor encerra sozinho de qualquer forma */ }
    const min = Math.round(c.ms / 60000);
    c.aoEncerrar(`Sua sessão foi encerrada após ${min} minuto${min === 1 ? "" : "s"} sem uso. Entre novamente.`);
  }

  function iniciar(opcoes) {
    parar();
    cfg = { ms: Math.max(60, opcoes.segundos || 300) * 1000, ping: opcoes.ping, sair: opcoes.sair, aoEncerrar: opcoes.aoEncerrar };
    ultimaAcao = ultimoServidor = agora();
    gravar(K_ACAO, ultimaAcao); gravar(K_SERV, ultimoServidor);
    relogio = setInterval(conferir, 1000);
  }

  function parar() {
    cfg = null;
    if (relogio) clearInterval(relogio);
    relogio = null;
    esconderAviso();
  }

  ["mousedown", "keydown", "touchstart", "wheel", "scroll", "mousemove", "input"].forEach((ev) =>
    window.addEventListener(ev, acao, { capture: true, passive: true }));
  document.addEventListener("visibilitychange", () => { if (!document.hidden) conferir(); });
  window.addEventListener("storage", (e) => {
    if (e.key === K_FIM && cfg) encerrar(false);  // outra aba encerrou a sessao (o cookie e o mesmo)
  });

  return { iniciar, parar, servidor };
})();

/* Portal - area do solicitante ("Meus chamados") */
(function () {
  "use strict";
  const $ = (s) => document.querySelector(s);
  const CORES = { 1: "#4f9fd1", 2: "#1f7a8c", 3: "#7d5ba6", 4: "#d98e04", 5: "#2e8b57", 6: "#5d6f7d" };
  const CORES_EVENTO = { abertura: "#9aa8b3", suporte: "#1f7a8c", cliente: "#4f9fd1", solucao: "#2e8b57",
                         aprovada: "#2e8b57", recusada: "#c0392b", fechamento: "#12324a" };
  const FILTROS = [
    { id: "todos", nome: "Todos", teste: () => true },
    { id: "novos", nome: "Novos", teste: (c) => c.status === 1 },
    { id: "andamento", nome: "Em atendimento", teste: (c) => c.status === 2 || c.status === 3 },
    { id: "pendentes", nome: "Pendentes", teste: (c) => c.status === 4 },
    { id: "solucionados", nome: "Solucionados", teste: (c) => c.status === 5 },
    { id: "fechados", nome: "Fechados", teste: (c) => c.status === 6 },
  ];
  const estado = { itens: [], filtro: "todos", aberto: null, dias: 30, total: 0, abertura: null };

  // todo conteudo do GLPI entra como texto, nunca como HTML
  function el(tag, classe, texto) {
    const e = document.createElement(tag);
    if (classe) e.className = classe;
    if (texto !== undefined && texto !== null) e.textContent = texto;
    return e;
  }
  function msg(alvo, tipo, texto) {
    alvo.hidden = !texto;
    alvo.className = `mensagem ${tipo}`;
    alvo.textContent = texto || "";
  }
  async function api(url, corpo) {
    const op = corpo === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(corpo) };
    const r = await fetch(url, op);
    const j = await r.json().catch(() => ({}));
    if (r.status === 401 && !url.endsWith("/login")) { telaLogin(); throw new Error(j.detail || "Entre novamente."); }
    if (!r.ok) throw new Error(j.detail || `Erro HTTP ${r.status}`);
    window.SessaoOciosa.servidor();  // toda requisicao com login renova a sessao no servidor
    return j;
  }

  // ------------------------------------------------------------ telas
  function telaLogin(aviso) {
    window.SessaoOciosa.parar();
    msg($("#l-msg"), "info", typeof aviso === "string" ? aviso : "");
    $("#tela-login").hidden = false;
    $("#tela-chamados").hidden = true;
    document.body.classList.remove("modo-atendimento");
    $("#l-usuario").focus();
  }
  async function telaChamados(eu) {
    $("#tela-login").hidden = true;
    $("#tela-chamados").hidden = false;
    document.body.classList.add("modo-atendimento");
    $("#cl-ola").textContent = `Olá, ${eu.nome}`;
    window.SessaoOciosa.iniciar({
      segundos: eu.ocioso, ping: "/api/cliente/me",
      sair: () => fetch("/api/cliente/logout", { method: "POST" }),
      aoEncerrar: (texto) => { $("#cl-detalhe").innerHTML = ""; telaLogin(texto); },
    });
    $("#cl-novo").hidden = !eu.pode_abrir;
    estado.dias = eu.dias || 30;
    $("#topo-sub").textContent = `Seus chamados abertos nos últimos ${estado.dias} dias.`;
    await carregar();
  }

  async function carregar(forcar) {
    $("#cl-total").textContent = "Carregando seus chamados…";
    $("#cl-lista").innerHTML = "";
    try {
      const r = await api(forcar === true ? "/api/cliente/chamados?atualizar=true" : "/api/cliente/chamados");
      estado.itens = r.itens;
      estado.dias = r.dias;
      estado.total = r.total || r.itens.length;
      desenharFiltros();
      desenharAvisos();
      desenharLista();
    } catch (e) {
      $("#cl-total").textContent = e.message;
    }
  }

  function desenharFiltros() {
    const box = $("#cl-filtros");
    box.innerHTML = "";
    FILTROS.forEach((f) => {
      const n = estado.itens.filter(f.teste).length;
      const b = el("button", "btn" + (estado.filtro === f.id ? " ativo" : ""), `${f.nome} (${n})`);
      b.type = "button";
      b.setAttribute("aria-pressed", estado.filtro === f.id);
      b.addEventListener("click", () => { estado.filtro = f.id; desenharFiltros(); desenharLista(); });
      box.appendChild(b);
    });
  }

  function desenharAvisos() {
    const box = $("#cl-avisos");
    box.innerHTML = "";
    const pend = estado.itens.filter((c) => c.status === 4).length;
    const sol = estado.itens.filter((c) => c.status === 5).length;
    if (pend) box.appendChild(el("p", "mensagem alerta-cl", `${pend} chamado(s) aguardando a sua resposta.`));
    if (sol) box.appendChild(el("p", "mensagem ok", `${sol} chamado(s) solucionado(s) aguardando a sua avaliação.`));
  }

  function desenharLista() {
    const filtro = FILTROS.find((f) => f.id === estado.filtro);
    const itens = estado.itens.filter(filtro.teste);
    const lista = $("#cl-lista");
    lista.innerHTML = "";
    let texto = estado.itens.length
      ? `${itens.length} de ${estado.itens.length} chamado(s) dos últimos ${estado.dias} dias`
      : `Você não abriu chamados nos últimos ${estado.dias} dias.`;
    if (estado.total > estado.itens.length) {
      texto = `${itens.length} chamado(s) neste filtro. Mostrando os ${estado.itens.length} mais recentes de ${estado.total} dos últimos ${estado.dias} dias.`;
    }
    $("#cl-total").textContent = texto;
    itens.forEach((c) => {
      const li = el("li");
      const b = el("button", "item-at" + (estado.aberto === c.id ? " ativo" : ""));
      b.type = "button";
      b.dataset.id = c.id;
      b.style.setProperty("--cor-status", CORES[c.status] || "#5d6f7d");
      const l1 = el("div", "linha1");
      l1.append(el("span", "", `#${c.id} · ${c.nome_status}`), el("span", "", c.atualizacao ? `atualizado ${c.atualizacao}` : ""));
      b.append(l1, el("div", "tit", c.titulo || "(sem título)"));
      b.appendChild(el("div", "linha1", c.tecnicos.length ? `Técnico: ${c.tecnicos.join(", ")}` : "Aguardando um técnico"));
      if (c.status === 4) b.appendChild(el("div", "acao-cl", "Responda para continuar o atendimento"));
      if (c.status === 5) b.appendChild(el("div", "acao-cl ok", "Avalie a solução"));
      b.addEventListener("click", () => abrir(c.id));
      li.appendChild(b);
      lista.appendChild(li);
    });
  }

  // ------------------------------------------------------------ detalhe e acoes
  async function abrir(id) {
    estado.aberto = id;
    document.querySelectorAll(".item-at").forEach((b) => b.classList.toggle("ativo", b.dataset.id === String(id)));
    const box = $("#cl-detalhe");
    box.innerHTML = "";
    box.appendChild(el("p", "sutil-at", `Carregando o chamado ${id}…`));
    try {
      desenharDetalhe(await api(`/api/cliente/chamado/${id}`));
    } catch (e) {
      box.innerHTML = "";
      box.appendChild(el("p", "mensagem erro", e.message));
    }
    if (window.innerWidth < 960) box.scrollIntoView({ behavior: "smooth" });
  }

  function desenharDetalhe(c, aviso) {
    const box = $("#cl-detalhe");
    box.innerHTML = "";
    box.style.setProperty("--cor-status", CORES[c.status.codigo] || "#5d6f7d");
    const cab = el("div", "cabecalho-chamado");
    const t = el("div");
    t.append(el("div", "numero", `Chamado nº ${c.numero}`), el("h2", "", c.titulo || "(sem título)"));
    cab.append(t, el("span", "selo", c.status.nome));
    box.appendChild(cab);
    if (c.status.explicacao) box.appendChild(el("p", "explicacao", c.status.explicacao));
    if (aviso) box.appendChild(el("p", "mensagem ok", aviso));

    const dl = el("dl", "dados");
    const dado = (r, v) => { if (!v) return; const d = el("div"); d.append(el("dt", "", r), el("dd", "", v)); dl.appendChild(d); };
    dado("Aberto em", c.abertura);
    dado("Técnico", c.tecnicos ? c.tecnicos.join(", ") : "Aguardando um técnico");
    dado("Categoria", c.categoria);
    dado("Solucionado em", c.solucao);
    dado("Fechado em", c.fechamento);
    box.appendChild(dl);

    if (c.descricao) {
      const h = el("h3", "secao-titulo", "Descrição"); h.style.marginTop = "18px";
      box.append(h, el("p", "texto-livre", c.descricao));
    }
    if (c.historico && c.historico.length) {
      const h = el("h3", "secao-titulo", "Histórico"); h.style.marginTop = "18px";
      box.appendChild(h);
      const ol = el("ol", "linha-tempo");
      c.historico.forEach((ev) => {
        const li = el("li", `evento ${ev.tipo}`);
        li.style.setProperty("--cor-evento", CORES_EVENTO[ev.tipo] || "#9aa8b3");
        li.appendChild(el("div", "quando", ev.data));
        if (ev.autor) {
          li.append(el("div", "quem", ev.tipo === "solucao" ? `Solução registrada por ${ev.autor}` : ev.autor),
                    el("div", "balao texto-livre", ev.texto || "(sem texto)"));
        } else {
          li.appendChild(el("div", "simples", ev.texto));
        }
        ol.appendChild(li);
      });
      box.appendChild(ol);
    }

    if (c.pode_responder) box.appendChild(formResponder(c));
    if (c.pode_avaliar) box.appendChild(formAvaliar(c));
  }

  function formResponder(c) {
    const f = el("form", "resposta-at");
    f.appendChild(el("h3", "secao-titulo", "Sua resposta"));
    f.appendChild(el("p", "sutil-at", "A equipe está aguardando um retorno seu para continuar o atendimento."));
    const ta = el("textarea"); ta.required = true; ta.maxLength = 5000; ta.placeholder = "Escreva a sua resposta…";
    const res = el("div", "mensagem"); res.hidden = true;
    const bt = el("button", "btn primario", "Enviar resposta"); bt.type = "submit";
    const botoes = el("div", "botoes"); botoes.appendChild(bt);
    f.append(ta, res, botoes);
    f.addEventListener("submit", async (e) => {
      e.preventDefault();
      bt.disabled = true; msg(res, "info", "Enviando…");
      try {
        const r = await api(`/api/cliente/chamado/${c.numero}/responder`, { texto: ta.value });
        await recarregarDepoisDaAcao(c.numero, r.message);
      } catch (err) { msg(res, "erro", err.message); bt.disabled = false; }
    });
    return f;
  }

  function formAvaliar(c) {
    const f = el("form", "resposta-at");
    f.appendChild(el("h3", "secao-titulo", "Avalie a solução"));
    f.appendChild(el("p", "sutil-at", "O problema foi resolvido? Marque uma opção."));
    const op = el("div", "opcoes");
    const opcao = (valor, titulo, ajuda) => {
      const l = el("label", "check");
      const r = el("input"); r.type = "radio"; r.name = `avaliacao-${c.numero}`; r.value = valor;
      const sp = el("span", "", titulo); sp.appendChild(el("small", "", ajuda));
      l.append(r, sp); op.appendChild(l);
      return r;
    };
    const rOk = opcao("sim", "Aprovo a solução", "O problema foi resolvido. O chamado será encerrado.");
    const rNao = opcao("nao", "Não aprovo a solução", "O problema continua. O chamado será reaberto para a equipe.");
    f.appendChild(op);
    const rot = el("label", "rotulo-cl", "Comentário (opcional)");
    const ta = el("textarea"); ta.maxLength = 5000; ta.placeholder = "Se quiser, deixe um comentário para a equipe.";
    const res = el("div", "mensagem"); res.hidden = true;
    const bt = el("button", "btn primario", "Enviar avaliação"); bt.type = "submit";
    const botoes = el("div", "botoes"); botoes.appendChild(bt);
    f.append(rot, ta, res, botoes);
    const ajustar = () => {
      const recusa = rNao.checked;
      rot.textContent = recusa ? "Por que a solução não resolveu? (obrigatório)" : "Comentário (opcional)";
      ta.required = recusa;
      ta.placeholder = recusa ? "Conte o que ainda está acontecendo." : "Se quiser, deixe um comentário para a equipe.";
      bt.textContent = recusa ? "Reabrir chamado" : rOk.checked ? "Aprovar e encerrar" : "Enviar avaliação";
    };
    rOk.addEventListener("change", ajustar);
    rNao.addEventListener("change", ajustar);
    f.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!rOk.checked && !rNao.checked) { msg(res, "erro", "Marque se aprova ou não aprova a solução."); return; }
      if (rNao.checked && ta.value.trim().length < 3) { msg(res, "erro", "Conte por que a solução não resolveu."); return; }
      bt.disabled = true; msg(res, "info", "Enviando…");
      try {
        const r = await api(`/api/cliente/chamado/${c.numero}/avaliar`, { aprovado: rOk.checked, comentario: ta.value });
        await recarregarDepoisDaAcao(c.numero, r.message);
      } catch (err) { msg(res, "erro", err.message); bt.disabled = false; }
    });
    return f;
  }

  // ------------------------------------------------------------ abrir chamado
  async function telaNovo() {
    estado.aberto = null;
    document.querySelectorAll(".item-at").forEach((b) => b.classList.remove("ativo"));
    const box = $("#cl-detalhe");
    box.innerHTML = "";
    box.style.setProperty("--cor-status", "#1f7a8c");
    box.appendChild(el("p", "sutil-at", "Carregando o formulário…"));
    if (window.innerWidth < 960) box.scrollIntoView({ behavior: "smooth" });
    try {
      if (!estado.abertura) estado.abertura = await api("/api/cliente/abertura");
    } catch (e) {
      box.innerHTML = "";
      box.appendChild(el("p", "mensagem erro", e.message));
      return;
    }
    box.innerHTML = "";
    box.appendChild(formNovo(estado.abertura));
  }

  function campo(rotulo, controle, obrigatorio, dica) {
    const l = el("label", "campo-novo");
    const t = el("span", "", rotulo);
    if (obrigatorio) t.appendChild(el("b", "obrig", " *"));
    l.append(t, controle);
    if (dica) l.appendChild(el("small", "", dica));
    return l;
  }

  function formNovo(o) {
    const f = el("form", "resposta-at novo-at");
    f.noValidate = true;
    f.appendChild(el("h2", "", "Abrir chamado"));
    f.appendChild(el("p", "sutil-at", "Descreva o que você precisa. A equipe de suporte recebe o chamado na hora."));

    // tipo
    let selTipo = null;
    if (o.tipo === "escolher") {
      selTipo = el("select");
      selTipo.append(new Option("Requisição (pedido, acesso, instalação…)", "2"), new Option("Incidente (algo parou ou está com erro)", "1"));
      f.appendChild(campo("Tipo", selTipo, true));
    }
    const tipoAtual = () => parseInt(selTipo ? selTipo.value : o.tipo, 10);

    // categoria
    let selCat = null;
    if (o.categoria !== "oculta" && o.categorias.length) {
      selCat = el("select");
      const preencherCategorias = () => {
        const antes = selCat.value;
        selCat.innerHTML = "";
        selCat.appendChild(new Option(o.categoria === "obrigatoria" ? "Escolha…" : "Não sei / outra", ""));
        const t = tipoAtual();
        o.categorias.filter((c) => (t === 2 ? c.requisicao : c.incidente))
          .forEach((c) => selCat.appendChild(new Option(c.nome, String(c.id))));
        if ([...selCat.options].some((op) => op.value === antes)) selCat.value = antes;
      };
      preencherCategorias();
      if (selTipo) selTipo.addEventListener("change", () => { preencherCategorias(); trocarFormulario(); });
      selCat.addEventListener("change", () => trocarFormulario());
      f.appendChild(campo("Categoria", selCat, o.categoria === "obrigatoria"));
    }

    // localizacao (busca por texto)
    let inLocal = null;
    const porNome = new Map();
    if (o.local !== "oculta" && o.locais.length) {
      const lista = el("datalist"); lista.id = "lista-locais";
      o.locais.forEach((l) => { porNome.set(l.nome.toLowerCase(), l.id); lista.appendChild(new Option(l.nome)); });
      inLocal = el("input"); inLocal.type = "text"; inLocal.setAttribute("list", "lista-locais");
      inLocal.placeholder = "Digite para buscar (ex.: Fortaleza)"; inLocal.autocomplete = "off";
      f.append(campo("Localização", inLocal, o.local === "obrigatoria", "Escolha uma opção da lista."), lista);
    }

    // formulario da categoria (Compras, Novo usuario...) aparece aqui
    const blocoForm = el("div", "bloco-form"); blocoForm.hidden = true;
    f.appendChild(blocoForm);

    // titulo e descricao
    const inTitulo = el("input"); inTitulo.type = "text"; inTitulo.maxLength = 250; inTitulo.placeholder = "Resumo em poucas palavras";
    let tituloSugerido = "";  // so troca o titulo se o usuario ainda nao escreveu o dele
    inTitulo.addEventListener("input", () => { tituloSugerido = null; });
    const taDesc = el("textarea"); taDesc.maxLength = 20000;
    const PH_DESC = "O que aconteceu ou o que você precisa? Inclua detalhes que ajudem a equipe.";
    taDesc.placeholder = PH_DESC;
    const rotDesc = campo("Descrição", taDesc, true);
    f.append(campo("Título", inTitulo, true), rotDesc);

    let formAtual = null;
    const respostas = {};  // id do campo -> controle (ou lista de checkboxes)
    function trocarFormulario() {
      const cat = selCat ? parseInt(selCat.value || "0", 10) : 0;
      const novo = (o.formularios || []).find((x) => x.categorias.includes(cat)) || null;
      if (novo === formAtual) return;
      formAtual = novo;
      blocoForm.innerHTML = "";
      Object.keys(respostas).forEach((k) => delete respostas[k]);
      blocoForm.hidden = !novo;
      // descricao: obrigatoria sem formulario; com formulario vira "Observações" opcional
      rotDesc.firstChild.textContent = novo ? "Observações" : "Descrição";
      rotDesc.querySelector(".obrig")?.remove();
      if (!novo) rotDesc.firstChild.appendChild(el("b", "obrig", " *"));
      taDesc.placeholder = novo ? "Algo mais que a equipe precise saber? (opcional)" : PH_DESC;
      if (tituloSugerido !== null) {
        tituloSugerido = novo ? (novo.titulo || novo.nome) : "";
        inTitulo.value = tituloSugerido;
      }
      if (!novo) return;
      blocoForm.appendChild(el("h3", "", novo.nome));
      if (novo.ajuda) blocoForm.appendChild(el("p", "sutil-at", novo.ajuda));
      novo.campos.forEach((c) => blocoForm.appendChild(controleDoCampo(c)));
    }
    function controleDoCampo(c) {
      if (c.tipo === "marcar") {
        const caixa = el("div", "campo-novo marcar-novo");
        const t = el("span", "", c.rotulo);
        if (c.obrigatorio) t.appendChild(el("b", "obrig", " *"));
        caixa.appendChild(t);
        respostas[c.id] = c.opcoes.map((op) => {
          const l = el("label", "check-novo"); const cb = el("input"); cb.type = "checkbox"; cb.value = op;
          l.append(cb, el("span", "", op)); caixa.appendChild(l);
          return cb;
        });
        return caixa;
      }
      let i;
      if (c.tipo === "textolongo") { i = el("textarea"); i.maxLength = 5000; i.classList.add("curto"); }
      else if (c.tipo === "lista") {
        i = el("select"); i.appendChild(new Option("Escolha…", ""));
        c.opcoes.forEach((op) => i.appendChild(new Option(op, op)));
      } else {
        i = el("input");
        i.type = { data: "date", email: "email" }[c.tipo] || "text";
        i.maxLength = c.tipo === "numero" ? 30 : 500;
        if (c.tipo === "numero") i.inputMode = "decimal";
      }
      respostas[c.id] = i;
      return campo(c.rotulo, i, c.obrigatorio);
    }
    function lerRespostas() {
      const r = {};
      for (const c of formAtual.campos) {
        const ctl = respostas[c.id];
        if (c.tipo === "marcar") {
          r[c.id] = ctl.filter((cb) => cb.checked).map((cb) => cb.value);
          if (c.obrigatorio && !r[c.id].length) return { erro: `Marque pelo menos uma opção em ${c.rotulo}.`, foco: ctl[0] };
        } else {
          r[c.id] = ctl.value.trim();
          if (c.obrigatorio && !r[c.id]) return { erro: `Preencha o campo ${c.rotulo}.`, foco: ctl };
          if (r[c.id] && c.tipo === "numero" && !/^-?\d+([.,]\d+)?$/.test(r[c.id].replace(/\s/g, ""))) return { erro: `O campo ${c.rotulo} aceita só números.`, foco: ctl };
          if (r[c.id] && c.tipo === "email" && !ctl.checkValidity()) return { erro: `O campo ${c.rotulo} precisa de um e-mail válido.`, foco: ctl };
        }
      }
      return { respostas: r };
    }

    // campos extras configurados pelo administrador
    const extras = {};
    o.extras.forEach((x) => {
      const i = el("input"); i.type = "text"; i.maxLength = 500;
      extras[x.id] = i;
      f.appendChild(campo(x.rotulo, i, x.obrigatorio));
    });

    const res = el("div", "mensagem"); res.hidden = true;
    const bt = el("button", "btn primario", "Abrir chamado"); bt.type = "submit";
    const cancelar = el("button", "btn", "Cancelar"); cancelar.type = "button";
    cancelar.addEventListener("click", () => { $("#cl-detalhe").innerHTML = ""; $("#cl-detalhe").appendChild(el("p", "sutil-at", "Selecione um chamado na lista.")); });
    const botoes = el("div", "botoes"); botoes.append(cancelar, bt);
    f.append(res, botoes);

    f.addEventListener("submit", async (e) => {
      e.preventDefault();
      const erro = (t, foco) => { msg(res, "erro", t); if (foco) foco.focus(); };
      if (inTitulo.value.trim().length < 3) return erro("Escreva um título para o chamado.", inTitulo);
      if (selCat && o.categoria === "obrigatoria" && !selCat.value) return erro("Escolha a categoria.", selCat);
      let formulario = null;
      if (formAtual) {
        const lido = lerRespostas();
        if (lido.erro) return erro(lido.erro, lido.foco);
        formulario = { id: formAtual.id, respostas: lido.respostas };
      } else if (taDesc.value.trim().length < 5) return erro("Descreva o que você precisa.", taDesc);
      let local = 0;
      if (inLocal) {
        const txt = inLocal.value.trim().toLowerCase();
        if (txt) {
          local = porNome.get(txt) || 0;
          if (!local) return erro("Escolha a localização clicando em uma opção da lista.", inLocal);
        } else if (o.local === "obrigatoria") return erro("Escolha a localização.", inLocal);
      }
      const valores = {};
      for (const x of o.extras) {
        valores[x.id] = extras[x.id].value.trim();
        if (x.obrigatorio && !valores[x.id]) return erro(`Preencha o campo ${x.rotulo}.`, extras[x.id]);
      }
      bt.disabled = true; msg(res, "info", "Enviando…");
      try {
        const r = await api("/api/cliente/abrir", {
          titulo: inTitulo.value, descricao: taDesc.value, tipo: tipoAtual(),
          categoria: selCat ? parseInt(selCat.value || "0", 10) : 0, local, extras: valores, formulario,
        });
        estado.filtro = "todos";
        desenharFiltros();
        await carregar(true);
        await abrir(r.id);
        const box = $("#cl-detalhe");
        const aviso = el("p", "mensagem ok", r.message);
        box.insertBefore(aviso, box.children[1] || null);
      } catch (err) {
        bt.disabled = false;
        msg(res, "erro", err.message);
      }
    });
    setTimeout(() => (selTipo || inTitulo).focus(), 50);
    return f;
  }

  async function recarregarDepoisDaAcao(id, mensagem) {
    await carregar();
    try { desenharDetalhe(await api(`/api/cliente/chamado/${id}`), mensagem); }
    catch (e) { /* lista ja atualizada */ }
  }

  // ------------------------------------------------------------ eventos
  $("#form-login").addEventListener("submit", async (e) => {
    e.preventDefault();
    const bt = $("#form-login button[type=submit]");
    bt.disabled = true; bt.textContent = "Entrando…";
    try {
      await api("/api/cliente/login", { username: $("#l-usuario").value.trim(), password: $("#l-senha").value });
      $("#l-senha").value = "";
      msg($("#l-msg"), "erro", "");
      telaChamados(await api("/api/cliente/me"));
    } catch (err) { msg($("#l-msg"), "erro", err.message); }
    finally { bt.disabled = false; bt.textContent = "Entrar"; }
  });
  $("#cl-sair").addEventListener("click", async () => { window.SessaoOciosa.parar(); await fetch("/api/cliente/logout", { method: "POST" }); telaLogin(); });
  $("#cl-atualizar").addEventListener("click", () => carregar(true));
  $("#cl-novo").addEventListener("click", telaNovo);

  fetch("/api/cliente/me").then(async (r) => (r.ok ? telaChamados(await r.json()) : telaLogin())).catch(telaLogin);
})();

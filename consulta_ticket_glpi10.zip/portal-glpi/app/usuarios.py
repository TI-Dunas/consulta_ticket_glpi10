"""Usuarios do painel: cadastro, senhas (PBKDF2) e sessao por cookie assinado."""
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import threading
import time
from datetime import datetime

PAPEIS = {"admin": "Administrador", "viewer": "Somente visualização"}
ITERACOES = 200_000
DURACAO_SESSAO = int(os.environ.get("SESSION_HOURS", "12")) * 3600
NOME_VALIDO = re.compile(r"^[A-Za-z0-9._-]{3,40}$")
TRAVA = threading.Lock()


class ErroUsuario(Exception):
    pass


class Usuarios:
    def __init__(self, pasta):
        self.arquivo = os.path.join(pasta, "users.json")
        self.arq_chave = os.path.join(pasta, "secret.key")
        self.pasta = pasta

    # ------------------------------------------------------------ armazenamento
    def _ler(self):
        try:
            with open(self.arquivo, encoding="utf-8") as f:
                return json.load(f).get("users", [])
        except (FileNotFoundError, json.JSONDecodeError):
            return []

    def _gravar(self, lista):
        os.makedirs(self.pasta, exist_ok=True)
        tmp = self.arquivo + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"users": lista}, f, ensure_ascii=False, indent=2)
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.arquivo)

    def _chave(self):
        if not os.path.exists(self.arq_chave):
            os.makedirs(self.pasta, exist_ok=True)
            with open(self.arq_chave, "w") as f:
                f.write(secrets.token_hex(32))
            os.chmod(self.arq_chave, 0o600)
        with open(self.arq_chave) as f:
            return f.read().strip().encode()

    @staticmethod
    def _hash(senha, sal):
        return hashlib.pbkdf2_hmac("sha256", senha.encode(), bytes.fromhex(sal), ITERACOES).hex()

    @staticmethod
    def publico(u):
        return {"username": u["username"], "name": u.get("name") or u["username"],
                "role": u.get("role", "viewer"), "role_label": PAPEIS.get(u.get("role"), ""),
                "created": u.get("created", "")}

    # ------------------------------------------------------------ inicializacao
    def garantir_admin_inicial(self, usuario, senha):
        """Na primeira execucao cria o administrador com os dados do docker-compose."""
        with TRAVA:
            if self._ler():
                return
            usuario = usuario if NOME_VALIDO.match(usuario or "") else "admin"
            senha = senha or "admin"
            sal = secrets.token_hex(16)
            self._gravar([{"username": usuario, "name": "Administrador", "role": "admin",
                           "salt": sal, "hash": self._hash(senha, sal),
                           "created": datetime.now().strftime("%d/%m/%Y %H:%M")}])

    # ------------------------------------------------------------ autenticacao
    def autenticar(self, usuario, senha):
        for u in self._ler():
            if u["username"].lower() == (usuario or "").lower():
                if hmac.compare_digest(u["hash"], self._hash(senha or "", u["salt"])):
                    return self.publico(u)
                return None
        self._hash(senha or "", "00" * 16)  # tempo constante mesmo quando o usuario nao existe
        return None

    def criar_sessao(self, usuario, ocioso, maximo=None):
        """Token assinado "usuario|expira|maximo": expira = agora + tempo ocioso (renovado a cada acao,
        ver renovar_sessao) e maximo = limite total desde o login."""
        agora = int(time.time())
        maximo = int(maximo or agora + DURACAO_SESSAO)
        corpo = f"{usuario}|{min(agora + int(ocioso), maximo)}|{maximo}"
        assinatura = hmac.new(self._chave(), corpo.encode(), hashlib.sha256).hexdigest()
        return base64.urlsafe_b64encode(f"{corpo}|{assinatura}".encode()).decode()

    def _abrir(self, token):
        try:
            usuario, expira, maximo, assinatura = base64.urlsafe_b64decode(token.encode()).decode().split("|")
            expira, maximo = int(expira), int(maximo)
        except Exception:  # noqa: BLE001  (inclui tokens do formato antigo: o usuario entra de novo)
            return None
        esperado = hmac.new(self._chave(), f"{usuario}|{expira}|{maximo}".encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(esperado, assinatura) or expira < time.time():
            return None
        return usuario, expira, maximo

    def ler_sessao(self, token):
        aberto = self._abrir(token)
        if not aberto:
            return None
        u = self.buscar(aberto[0])
        return self.publico(u) if u else None

    def renovar_sessao(self, token, ocioso, margem=15):
        """Novo token com o prazo de inatividade renovado, ou None se ainda nao precisa (ou se e invalido)."""
        aberto = self._abrir(token)
        if not aberto or aberto[1] - time.time() >= ocioso - margem:
            return None
        return self.criar_sessao(aberto[0], ocioso, aberto[2])

    # ------------------------------------------------------------ cadastro
    def buscar(self, usuario):
        return next((u for u in self._ler() if u["username"].lower() == (usuario or "").lower()), None)

    def listar(self):
        return [self.publico(u) for u in sorted(self._ler(), key=lambda x: x["username"].lower())]

    @staticmethod
    def _validar_senha(senha):
        if len(senha or "") < 8:
            raise ErroUsuario("A senha precisa ter pelo menos 8 caracteres.")

    def criar(self, usuario, nome, papel, senha):
        if not NOME_VALIDO.match(usuario or ""):
            raise ErroUsuario("Usuário inválido: use de 3 a 40 letras, números, ponto, hífen ou sublinhado.")
        if papel not in PAPEIS:
            raise ErroUsuario("Perfil inválido.")
        self._validar_senha(senha)
        with TRAVA:
            lista = self._ler()
            if any(u["username"].lower() == usuario.lower() for u in lista):
                raise ErroUsuario(f"O usuário '{usuario}' já existe.")
            sal = secrets.token_hex(16)
            lista.append({"username": usuario, "name": (nome or usuario).strip()[:80], "role": papel,
                          "salt": sal, "hash": self._hash(senha, sal),
                          "created": datetime.now().strftime("%d/%m/%Y %H:%M")})
            self._gravar(lista)

    def alterar(self, usuario, nome=None, papel=None, senha=None):
        with TRAVA:
            lista = self._ler()
            u = next((x for x in lista if x["username"].lower() == usuario.lower()), None)
            if not u:
                raise ErroUsuario("Usuário não encontrado.")
            if papel is not None:
                if papel not in PAPEIS:
                    raise ErroUsuario("Perfil inválido.")
                admins = [x for x in lista if x.get("role") == "admin"]
                if u.get("role") == "admin" and papel != "admin" and len(admins) <= 1:
                    raise ErroUsuario("É preciso manter pelo menos um administrador.")
                u["role"] = papel
            if nome is not None:
                u["name"] = nome.strip()[:80] or u["username"]
            if senha:
                self._validar_senha(senha)
                u["salt"] = secrets.token_hex(16)
                u["hash"] = self._hash(senha, u["salt"])
            self._gravar(lista)

    def remover(self, usuario, quem_remove):
        if usuario.lower() == quem_remove.lower():
            raise ErroUsuario("Você não pode remover o seu próprio usuário.")
        with TRAVA:
            lista = self._ler()
            u = next((x for x in lista if x["username"].lower() == usuario.lower()), None)
            if not u:
                raise ErroUsuario("Usuário não encontrado.")
            if u.get("role") == "admin" and sum(1 for x in lista if x.get("role") == "admin") <= 1:
                raise ErroUsuario("É preciso manter pelo menos um administrador.")
            self._gravar([x for x in lista if x is not u])
